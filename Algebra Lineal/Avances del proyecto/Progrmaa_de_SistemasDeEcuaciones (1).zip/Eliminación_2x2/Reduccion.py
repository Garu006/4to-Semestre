# -*- coding: utf-8 -*-
"""
Reducción / Eliminación 2×2 (con fracciones exactas y ecuaciones escritas como texto)

Este módulo:
1) Convierte dos ecuaciones escritas como texto (ej. "2x - 3y = 7")
   a la forma normalizada a·x + b·y = c usando fracciones exactas.
2) Clasifica el sistema (solución única / infinitas / ninguna).
3) Si hay solución única, aplica eliminación por suma/resta (sin matrices) y
   muestra el procedimiento.

Se diseñó para ser legible en clase/cuaderno, evitando errores de redondeo.
"""

from fractions import Fraction
import re


# ─────────────────────────── Formato de salida ───────────────────────────

def formatear_fraccion(numero: Fraction) -> str:
    """
    Representa una fracción como:
        - entero si el denominador es 1 (p. ej., 6)
        - 'p/q' en caso contrario (p. ej., 7/3)
    """
    return f"{numero.numerator}" if numero.denominator == 1 else f"{numero.numerator}/{numero.denominator}"


# ─────────────── Patrones (regex) para leer ecuaciones en texto ───────────────
# Acepta enteros (3), fracciones (3/4) y decimales (2.5). Maneja signos y espacios.
PATRON_NUMERO = r'(?:\d+(?:/\d+)?|\d*\.\d+)'
PATRON_COEFICIENTE_OPCIONAL = r'([+-]?\s*(?:\d+(?:/\d+)?|\d*\.\d+)?)'
PATRON_VAR_X = r'(?:\*?\s*[xX])'
PATRON_VAR_Y = r'(?:\*?\s*[yY])'


# ───────────────────────────── Parseo de ecuaciones ─────────────────────────────

def buscar_coeficiente(texto_lado: str, variable: str) -> Fraction:
    """
    Extrae el coeficiente de 'x' o 'y' en un lado de la ecuación (como fracción).
    - Si el término no aparece, devuelve 0.
    - Si aparece sin número explícito (ej. '+x' o '-y'), interpreta ±1.
    """
    patron_variable = re.compile(
        PATRON_COEFICIENTE_OPCIONAL + (PATRON_VAR_X if variable == 'x' else PATRON_VAR_Y)
    )
    coincidencia = patron_variable.search(texto_lado)
    if not coincidencia:
        return Fraction(0)

    texto_numerico = coincidencia.group(1).replace(' ', '')
    if texto_numerico in ('', '+', '-'):
        return Fraction(1 if texto_numerico != '-' else -1)

    return Fraction(texto_numerico)


def parsear_ecuacion(texto_ecuacion: str) -> tuple[Fraction, Fraction, Fraction]:
    """
    Convierte una ecuación en texto del tipo:
        "a x + b y = c"   (con variaciones como 3x, 3*x, signos, espacios, decimales, fracciones)
    a la forma normalizada con fracciones exactas:
        (coef_x, coef_y, termino_independiente)  donde  coef_x·x + coef_y·y = termino_independiente.

    Estrategia:
    - Separa la ecuación por '=' en lado izquierdo y lado derecho.
    - Lleva todos los términos con x e y al lado izquierdo (restándolos si estaban a la derecha).
    - Deja en el lado derecho únicamente el término independiente (suma de números que queden).
    """
    if '=' not in texto_ecuacion:
        raise ValueError("La ecuación debe incluir el signo '='.")

    lado_izquierdo, lado_derecho = texto_ecuacion.split('=', 1)

    coef_x_izq = buscar_coeficiente(lado_izquierdo, 'x')
    coef_y_izq = buscar_coeficiente(lado_izquierdo, 'y')

    # Pasamos términos con variables desde el lado derecho hacia el izquierdo
    coef_x = coef_x_izq - buscar_coeficiente(lado_derecho, 'x')
    coef_y = coef_y_izq - buscar_coeficiente(lado_derecho, 'y')

    # Eliminamos de la derecha los términos con x e y para quedarnos con constantes
    sin_var = re.sub(PATRON_COEFICIENTE_OPCIONAL + PATRON_VAR_X, ' ', lado_derecho)
    sin_var = re.sub(PATRON_COEFICIENTE_OPCIONAL + PATRON_VAR_Y, ' ', sin_var).strip()

    termino_ind = Fraction(0)
    if sin_var:
        # Sumamos todos los números (con signo) que queden en el lado derecho
        for token in re.findall(r'[+-]?\s*(?:\d+(?:/\d+)?|\d*\.\d+)', sin_var):
            termino_ind += Fraction(token.replace(' ', ''))

    return coef_x, coef_y, termino_ind


# ────────────────────── Clasificación del sistema 2×2 ──────────────────────

def misma_razon(u1: Fraction, u2: Fraction, v1: Fraction, v2: Fraction) -> bool:
    """
    Comprueba si u1/u2 = v1/v2 usando productos cruzados (evita divisiones entre cero).
    """
    return u1 * v2 == v1 * u2


def clasificar_sistema(
    a1: Fraction, b1: Fraction, c1: Fraction,
    a2: Fraction, b2: Fraction, c2: Fraction
) -> str:
    """
    Clasifica el sistema según los coeficientes:
    - 'unica'      → determinante ≠ 0
    - 'infinitas'  → (a1:b1:c1) y (a2:b2:c2) proporcionales (misma recta)
    - 'ninguna'    → (a1:b1) proporcionales pero c no proporcional (rectas paralelas)
    """
    det = a1 * b2 - a2 * b1
    if det != 0:
        return "unica"

    mismos_ab = misma_razon(a1, a2, b1, b2)
    mismos_c  = misma_razon(a1, a2, c1, c2)

    if mismos_ab and mismos_c:
        return "infinitas"
    if mismos_ab and not mismos_c:
        return "ninguna"
    return "ninguna"  # Caso degenerado con det=0


# ─────────────────── Eliminación por suma/resta (sin matrices) ───────────────────

def contar_terminos_presentes(a: Fraction, b: Fraction) -> int:
    """Cuenta cuántas variables aparecen en una ecuación (0, 1 o 2)."""
    return (1 if a != 0 else 0) + (1 if b != 0 else 0)


def eliminar_por_suma_resta_2x2(
    a1: Fraction, b1: Fraction, c1: Fraction,
    a2: Fraction, b2: Fraction, c2: Fraction
) -> tuple[Fraction | None, Fraction | None, str]:
    """
    Aplica eliminación clásica (multiplicar y sumar/restar ecuaciones)
    para cancelar una variable y resolver la otra sin usar matrices.

    Devuelve: (x, y, estado) con estado en {'ok', 'dependiente', 'incompatible', 'degenerado'}.
    """
    # Heurística simple para elegir qué variable eliminar (menor “costo”)
    costo_x = abs(a1 * a2) if a1 != 0 and a2 != 0 else None
    costo_y = abs(b1 * b2) if b1 != 0 and b2 != 0 else None

    if costo_x is not None and (costo_y is None or costo_x <= costo_y):
        variable = 'x'
    elif costo_y is not None:
        variable = 'y'
    else:
        return None, None, 'degenerado'

    print(f"\n• Elegimos eliminar la variable '{variable}' mediante suma/resta de ecuaciones.")

    if variable == 'x':
        # Multiplicadores para oponer coeficientes de x
        m1 = a2
        m2 = -a1
        print(f"   Multiplico (1) por {formatear_fraccion(m1)} y (2) por {formatear_fraccion(m2)} para oponer coeficientes de x.")

        b1p, c1p = b1 * m1, c1 * m1
        b2p, c2p = b2 * m2, c2 * m2

        b_res = b1p + b2p
        c_res = c1p + c2p

        print("\n   Sumamos las ecuaciones escaladas (1) + (2) para eliminar x:")
        print(f"      {formatear_fraccion(b_res)}·y = {formatear_fraccion(c_res)}")

        if b_res == 0:
            return None, None, ('dependiente' if c_res == 0 else 'incompatible')

        y = c_res / b_res

        # Elegimos la ecuación original más simple para sustituir
        comp1 = contar_terminos_presentes(a1, b1)
        comp2 = contar_terminos_presentes(a2, b2)
        if comp1 <= comp2:
            x = (c1 - b1 * y) / a1 if a1 != 0 else None
        else:
            x = (c2 - b2 * y) / a2 if a2 != 0 else None

        return x, y, 'ok'

    else:  # eliminar 'y'
        m1 = b2
        m2 = -b1
        print(f"   Multiplico (1) por {formatear_fraccion(m1)} y (2) por {formatear_fraccion(m2)} para oponer coeficientes de y.")

        a1p, c1p = a1 * m1, c1 * m1
        a2p, c2p = a2 * m2, c2 * m2

        a_res = a1p + a2p
        c_res = c1p + c2p

        print("\n   Sumamos las ecuaciones escaladas (1) + (2) para eliminar y:")
        print(f"      {formatear_fraccion(a_res)}·x = {formatear_fraccion(c_res)}")

        if a_res == 0:
            return None, None, ('dependiente' if c_res == 0 else 'incompatible')

        x = c_res / a_res

        comp1 = contar_terminos_presentes(a1, b1)
        comp2 = contar_terminos_presentes(a2, b2)
        if comp1 <= comp2:
            y = (c1 - a1 * x) / b1 if b1 != 0 else None
        else:
            y = (c2 - a2 * x) / b2 if b2 != 0 else None

        return x, y, 'ok'


# ───────────────────────── Controlador principal ─────────────────────────

def resolver_eliminacion(ecuacion_texto_1: str, ecuacion_texto_2: str) -> None:
    """
    Orquesta el proceso:
      1) Parseo de las dos ecuaciones en texto.
      2) Impresión del sistema normalizado.
      3) Clasificación del sistema.
      4) Si hay solución única, aplicación del método de eliminación y muestra de resultados.
    """
    a1, b1, c1 = parsear_ecuacion(ecuacion_texto_1)
    a2, b2, c2 = parsear_ecuacion(ecuacion_texto_2)

    print("\nMétodo de Eliminación 2×2 (paso a paso)")
    print("\nSistema normalizado (a·x + b·y = c):")
    print(f"  (1) {formatear_fraccion(a1)}·x + {formatear_fraccion(b1)}·y = {formatear_fraccion(c1)}")
    print(f"  (2) {formatear_fraccion(a2)}·x + {formatear_fraccion(b2)}·y = {formatear_fraccion(c2)}")

    tipo = clasificar_sistema(a1, b1, c1, a2, b2, c2)
    if tipo == "unica":
        print("\nClasificación: determinante distinto de cero → **solución única**.")
        x, y, estado = eliminar_por_suma_resta_2x2(a1, b1, c1, a2, b2, c2)
        if estado == 'ok':
            print("\nResultado final:")
            print(f"  x = {formatear_fraccion(x)}")
            print(f"  y = {formatear_fraccion(y)}")
        else:
            print("\nSe presentó un caso degenerado inesperado durante la eliminación.")
    elif tipo == "infinitas":
        print("\nClasificación: razones (a:b:c) proporcionales → **infinitas soluciones** (sistema dependiente).")
        print("Interpretación: ambas ecuaciones representan la **misma recta**.")
    else:
        print("\nClasificación: (a:b) proporcionales pero constantes distintas → **sin solución** (incompatible).")
        print("Interpretación: las rectas son **paralelas y distintas**.")


# ─────────────────────────── Entrada por consola ───────────────────────────

def main() -> None:
    """
    Pequeña interfaz por consola:
    pide las dos ecuaciones al usuario y muestra el procedimiento.
    """
    print("Ingrese dos ecuaciones lineales en x e y (ejemplo: '2x - 3y = 7').")
    ecuacion_1 = input("Ecuación 1: ")
    ecuacion_2 = input("Ecuación 2: ")
    resolver_eliminacion(ecuacion_1, ecuacion_2)


if __name__ == "__main__":
    main()
