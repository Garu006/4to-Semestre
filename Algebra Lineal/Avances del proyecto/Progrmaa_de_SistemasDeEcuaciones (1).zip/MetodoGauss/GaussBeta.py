from __future__ import annotations  # Permite anotar tipos de clases definidas después en el archivo
from dataclasses import dataclass  # Decorador para crear clases de datos sin boilerplate
from fractions import Fraction  # Tipo numérico racional exacto (evita errores de redondeo)
from typing import List, Tuple, Optional, Dict  # Tipos para anotar estructuras de datos
import re  # Módulo de expresiones regulares para parsear ecuaciones de texto

Numero = Fraction  # Alias: en todo el programa, manejamos números como Fraction para exactitud

# Validaciones de entrada
# Lista blanca de caracteres permitidos en toda la línea (bloquea llaves, corchetes, etc.)
_RE_CARACTERES = re.compile(r'^[0-9A-Za-z+\-*/.= \t]+$')

# Números válidos: entero (12), fracción (7/2) o decimal (0.25)
_P_NUM = r'(?:\d+(?:/\d+)?|\d*\.\d+)'

# Variable válida: comienza con letra y puede tener dígitos/guion_bajo después (x, y, z, x1, var2)
_P_VAR = r'(?:[A-Za-z]\w*)'

# Término con variable: [coef opcional][* opcional]variable   ej.: 3x, -1/2*y2, +x
_P_TERM_VAR = rf'(?:{_P_NUM}\s*\*?\s*)?{_P_VAR}'

# Término constante
_P_TERM_CONST = rf'{_P_NUM}'

# Un término (variable o constante) con signo inicial opcional
_P_TERM = rf'[+-]?\s*(?:{_P_TERM_VAR}|{_P_TERM_CONST})'

# Expresión lineal: Termino ( (+|-) Termino )*
_RE_EXPRESION = re.compile(rf'^\s*{_P_TERM}(?:\s*[+-]\s*{_P_TERM})*\s*$')

# Detección de presencia de una variable
_RE_TIENE_VAR = re.compile(_P_VAR)

def _es_ecuacion_lineal_valida(texto: str) -> Tuple[bool, Optional[str]]:
    """
    Valida que 'texto' sea una ecuación lineal con variables válidas.
    Reglas:
      - Solo caracteres en la lista blanca (_RE_CARACTERES)
      - Exactamente un '='
      - Ambos lados son expresiones lineales (_RE_EXPRESION)
      - Debe existir al menos UNA variable en toda la ecuación
      - No se permiten signos consecutivos '++', '+-', '--'
      - No se permite '* *', '*/', '/*', '//', etc.
    """
    linea = (texto or "").strip()
    if not linea:
        return False, "Línea vacía."
    if not _RE_CARACTERES.match(linea):
        return False, "Contiene caracteres no permitidos. Usa solo dígitos, letras, + - * / . = y espacios."
    if linea.count('=') != 1:
        return False, "Debe contener exactamente un signo '=' separando los dos lados."

    izq, der = [s.strip() for s in linea.split('=', 1)]

    if not _RE_EXPRESION.match(izq):
        return False, "El lado izquierdo no es una expresión lineal válida."
    if not _RE_EXPRESION.match(der):
        return False, "El lado derecho no es una expresión lineal válida."

    if not (_RE_TIENE_VAR.search(izq) or _RE_TIENE_VAR.search(der)):
        return False, "La ecuación no contiene variables."

    # Signos consecutivos
    if re.search(r'[\+\-]\s*[\+\-]', izq) or re.search(r'[\+\-]\s*[\+\-]', der):
        return False, "Hay signos consecutivos inválidos (por ejemplo '++' o '+-')."

    # Combinaciones inválidas con * y /
    if re.search(r'\*\s*[\*/]', linea) or re.search(r'/\s*[/\*]', linea):
        return False, "Uso inválido de operadores '*' o '/'."

    return True, None


# FORMATEO DE LA MATRIZ AUMENTADA [A|b] (ALINEADA POR COLUMNAS)

def _TextoDeNumero(Valor: Numero) -> str:
    """Convierte un Numero (Fraction) a texto legible ('3', '-2/5', '7/2')."""
    return str(Valor)  # Fraction ya formatea de manera adecuada; devolvemos su string

def GenerarLineasMatrizAumentada(Matriz: List[List[Numero]], Vector: List[Numero],
                                  Relleno: int = 2, AnchoMinimo: int = 2) -> List[str]:
    """
    Devuelve líneas de texto con [A|b] alineada por columnas.
    - Relleno: espacios entre columnas para dar “aire”.
    - AnchoMinimo: ancho mínimo por columna (estética).
    """
    if not Matriz:  # Si la matriz es vacía
        return ["[] | []"]  # Devuelve una representación mínima

    Filas: int = len(Matriz)  # Número de filas de A
    Columnas: int = len(Matriz[0])  # Número de columnas de A

    Anchos: List[int] = [AnchoMinimo] * Columnas  # Inicializa los anchos por columna
    for j in range(Columnas):  # Recorre cada columna
        LongitudMax: int = 0  # Guarda la longitud máxima encontrada en la columna j
        for i in range(Filas):  # Recorre cada fila
            LongitudMax = max(LongitudMax, len(_TextoDeNumero(Matriz[i][j])))  # Actualiza longitud máxima
        Anchos[j] = max(LongitudMax, AnchoMinimo)  # Fija el ancho definitivo de la columna j

    AnchoB: int = max(AnchoMinimo, max(len(_TextoDeNumero(Vector[i])) for i in range(Filas)))  # Ancho de la columna b

    Lineas: List[str] = []  # Lista de líneas resultantes
    for i in range(Filas):  # Recorre filas
        CeldasA: List[str] = []  # Celdas formateadas de A para la fila i
        for j in range(Columnas):  # Recorre columnas
            Texto = _TextoDeNumero(Matriz[i][j])  # Convierte A[i][j] a texto
            CeldasA.append(Texto.rjust(Anchos[j]))  # Alinea a la derecha según ancho calculado
        ParteA: str = (" " * Relleno).join(CeldasA)  # Une celdas de A con relleno
        TextoB: str = _TextoDeNumero(Vector[i]).rjust(AnchoB)  # Formatea b[i] alineado a la derecha
        Lineas.append(f"[ {ParteA} | {TextoB} ]")  # Construye la línea de la aumentada
    return Lineas  # Devuelve todas las líneas formateadas

# REGISTRO DE PASOS

class RegistroPasos:
    """Acumula mensajes y snapshots de [A|b] durante el algoritmo (modo detallado)."""
    def __init__(self) -> None:
        self.LineasDeRegistro: List[str] = []  # Lista de cadenas de texto registradas

    def Registrar(self, Mensaje: str) -> None:
        self.LineasDeRegistro.append(Mensaje)  # Agrega un mensaje sencillo al registro

    def RegistrarMatrizAumentada(self, Matriz: List[List[Numero]], Vector: List[Numero],
                                 Titulo: Optional[str] = None) -> None:
        """Registra la matriz aumentada [A|b] con columnas alineadas (opcionalmente con título)."""
        if Titulo is not None:  # Si se pasa un título
            self.LineasDeRegistro.append(Titulo)  # Lo agrega antes del bloque
        for Linea in GenerarLineasMatrizAumentada(Matriz, Vector, Relleno=2, AnchoMinimo=2):  # Genera líneas alineadas
            self.LineasDeRegistro.append(Linea)  # Agrega cada línea al registro
        self.LineasDeRegistro.append("")  # Agrega una línea en blanco como separador visual

    def ObtenerTexto(self) -> str:
        return "\n".join(self.LineasDeRegistro)  # Devuelve todo el registro como un único string

    def Limpiar(self) -> None:
        self.LineasDeRegistro.clear()  # Vacía el registro para reutilizar

# PARSER DE ECUACIONES EN TEXTO

class AnalizadorEcuacionesTexto:
    """Convierte ecuaciones en texto a (matriz A, vector b, lista de variables)."""
    _SeparadorTerminos = re.compile(r'([+-]?[^+-]+)')  # Separa términos conservando el signo
    _TerminoVariable = re.compile(  # Término con variable (coeficiente opcional + nombre)
        r'^([+-]?(?:\d+(?:\.\d+)?(?:/\d+(?:\.\d+)?)?)?)?([A-Za-z]\w*)$'
    )
    _NumeroPuro = re.compile(r'^[+-]?\d+(?:\.\d+)?(?:/\d+(?:\.\d+)?)?$')  # Constante pura (sin variable)

    @staticmethod
    def _FraccionDesdeTexto(Texto: str) -> Numero:
        """Convierte '+', '-', '2', '7/3', '-1.5' a Fraction exacta (maneja coeficiente implícito)."""
        Texto = Texto.strip()  # Quita espacios
        if Texto in ("", "+"):  # Coeficiente implícito +1
            return Fraction(1)  # Devuelve 1
        if Texto == "-":  # Coeficiente implícito -1
            return Fraction(-1)  # Devuelve -1
        if "/" in Texto:  # Caso fracción 'a/b'
            Num, Den = Texto.split("/", 1)  # Separa numerador y denominador
            return Fraction(Num) / Fraction(Den)  # Construye la fracción exacta
        return Fraction(Texto)  # Entero o decimal convertido a racional exacto

    @classmethod
    def _AnalizarLado(cls, Lado: str) -> Tuple[Dict[str, Numero], Numero]:
        """Parsea un lado de la ecuación y devuelve (coef_por_variable, suma_constantes)."""
        Lado = Lado.replace(" ", "")  # Elimina espacios para simplificar
        Terminos: List[str] = [t for t in cls._SeparadorTerminos.findall(Lado) if t.strip()]  # Separa términos
        CoefPorVar: Dict[str, Numero] = {}  # Diccionario acumulador de coeficientes por variable
        ConstAcum: Numero = Fraction(0)  # Acumulador de constantes puras
        for Termino in Terminos:  # Recorre cada término
            if any(ch.isalpha() for ch in Termino):  # Si hay letras, es término con variable
                M = cls._TerminoVariable.match(Termino)  # Intenta casar el patrón
                if not M:  # Sin match válido
                    raise ValueError(f"Término inválido: {Termino}")  # Lanza error de formato
                CoefTxt, VarNombre = M.groups()  # Extrae coeficiente (texto) y nombre de variable
                Coef = cls._FraccionDesdeTexto(CoefTxt or "1")  # Convierte a fracción (1 si vacío)
                CoefPorVar[VarNombre] = CoefPorVar.get(VarNombre, Fraction(0)) + Coef  # Acumula coeficiente
            else:  # Si no hay letras, es constante pura
                if not cls._NumeroPuro.match(Termino):  # Valida que sea número válido
                    raise ValueError(f"Constante inválida: {Termino}")  # Error si no lo es
                ConstAcum += cls._FraccionDesdeTexto(Termino)  # Suma la constante
        return CoefPorVar, ConstAcum  # Devuelve diccionario de coeficientes y suma de constantes

    @staticmethod
    def _ClaveNatural(Nombre: str):
        """Ordena variables de forma natural: x, x1, x2, x10 (alfabético + numérico)."""
        Pref = ''.join(ch for ch in Nombre if ch.isalpha())  # Extrae parte alfabética
        Suf = Nombre[len(Pref):]  # Extrae parte numérica (si existe)
        Num = int(Suf) if Suf.isdigit() else -1  # Convierte sufijo a entero o -1
        return (Pref, Num, Nombre)  # Devuelve tupla clave de orden

    @classmethod
    def AnalizarEcuaciones(cls, Ecuaciones: List[str]) -> Tuple[List[List[Numero]], List[Numero], List[str]]:
        """Convierte ecuaciones en texto a (A, b, variables) en orden natural."""
        FilasCoef: List[Dict[str, Numero]] = []  # Lista de dicts (una fila de A por ecuación)
        VectorB: List[Numero] = []  # Vector b de términos independientes
        VarsVistas = set()  # Conjunto de variables detectadas

        for Eq in Ecuaciones:  # Recorre cada ecuación
            # Validación robusta adicional por si llaman este método sin pasar por la entrada interactiva
            ok, msg = _es_ecuacion_lineal_valida(Eq)
            if not ok:
                raise ValueError(f"Ecuación inválida: {msg}. Texto recibido: {Eq}")

            if "=" not in Eq:  # (seguridad extra; ya lo vio el validador)
                raise ValueError(f"Ecuación sin '=': {Eq}")  # Error si falta
            Izq, Der = Eq.split("=", 1)  # Separa lados de la ecuación
            CoefIzq, ConstIzq = cls._AnalizarLado(Izq)  # Parseo lado izquierdo
            CoefDer, ConstDer = cls._AnalizarLado(Der)  # Parseo lado derecho

            Fila: Dict[str, Numero] = {}  # Coeficientes netos de la fila
            for var, c in CoefIzq.items():  # Suma coeficientes del lado izquierdo
                Fila[var] = Fila.get(var, Fraction(0)) + c  # Acumula
            for var, c in CoefDer.items():  # Resta coeficientes del lado derecho
                Fila[var] = Fila.get(var, Fraction(0)) - c  # Acumula con signo opuesto

            ConstLhs: Numero = ConstIzq - ConstDer  # Constante neta que queda en el LHS
            FilasCoef.append(Fila)  # Agrega la fila de coeficientes
            VectorB.append(-ConstLhs)  # Pasa constante al RHS: b = -(ConstIzq - ConstDer)
            VarsVistas.update(Fila.keys())  # Añade variables vistas

        Variables: List[str] = sorted(VarsVistas, key=cls._ClaveNatural)  # Ordena variables de forma natural
        n: int = len(FilasCoef)  # Número de ecuaciones
        m: int = len(Variables)  # Número de variables

        MatrizA: List[List[Numero]] = [[Fraction(0) for _ in range(m)] for _ in range(n)]  # Inicializa A
        for i, Dic in enumerate(FilasCoef):  # Recorre filas
            for j, Var in enumerate(Variables):  # Recorre columnas según orden de variables
                MatrizA[i][j] = Dic.get(Var, Fraction(0))  # Coloca coeficiente o 0 si falta

        return MatrizA, VectorB, Variables  # Devuelve A, b y lista de variables
    
# RESULTADO DE GAUSS (TRIANGULAR + CLASIFICACIÓN INTERNA)

@dataclass
class ResultadoGauss:
    MatrizTriangularSuperior: List[List[Numero]]  # Matriz A tras la eliminación hacia adelante
    VectorTransformado: List[Numero]  # Vector b transformado
    RangoDeA: int  # Rango(A) calculado internamente (para clasificar, no se imprime)
    RangoDeAumentada: int  # Rango([A|b]) calculado internamente (para clasificar, no se imprime)

# ELIMINADOR DE GAUSS

class EliminadorGauss:
    """Implementa Gauss clásico: anula debajo del pivote y luego resuelve por sustitución hacia atrás."""

    @staticmethod
    def CopiarMatriz(MatrizOriginal: List[List[Numero]]) -> List[List[Numero]]:
        return [Fila[:] for Fila in MatrizOriginal]  # Copia por filas para no alterar la original

    @staticmethod
    def CopiarVector(VectorOriginal: List[Numero]) -> List[Numero]:
        return VectorOriginal[:]  # Copia superficial del vector

    @staticmethod
    def EsFilaCero(Fila: List[Numero]) -> bool:
        return all(Valor == 0 for Valor in Fila)  # True si todos los elementos son cero

    @staticmethod
    def EliminacionHaciaAdelante(MatrizEntrada: List[List[Numero]], VectorEntrada: List[Numero],
                                 Registro: Optional[RegistroPasos] = None) -> ResultadoGauss:
        """Realiza la eliminación hacia adelante con pivoteo parcial. No imprime pivotes ni rangos."""
        A: List[List[Numero]] = EliminadorGauss.CopiarMatriz(MatrizEntrada)  # Copia de trabajo de A
        b: List[Numero] = EliminadorGauss.CopiarVector(VectorEntrada)  # Copia de trabajo de b
        nFilas: int = len(A)  # Cantidad de ecuaciones
        nCols: int = len(A[0]) if A else 0  # Cantidad de variables
        filaAct: int = 0  # Fila activa donde se colocará el siguiente pivote
        colAct: int = 0  # Columna activa donde se buscará el pivote

        if Registro is not None:  # Si se pidió registrar pasos
            Registro.RegistrarMatrizAumentada(A, b, "Estado inicial [A|b]:")  # Guarda snapshot inicial

        while filaAct < nFilas and colAct < nCols:  # Bucle principal de Gauss
            filaMax: int = max(range(filaAct, nFilas), key=lambda i: abs(A[i][colAct]))  # Selecciona la mejor fila (pivoteo parcial)
            if A[filaMax][colAct] == 0:  # Si la columna actual es toda cero
                colAct += 1  # Avanza a la siguiente columna
                continue  # Reintenta búsqueda de pivote en la nueva columna

            if filaMax != filaAct:  # Si la mejor fila no es la actual
                A[filaAct], A[filaMax] = A[filaMax], A[filaAct]  # Intercambia filas en A
                b[filaAct], b[filaMax] = b[filaMax], b[filaAct]  # Intercambia términos en b
                if Registro is not None:  # Si se registra
                    Registro.RegistrarMatrizAumentada(A, b, f"Intercambio de filas {filaAct} <-> {filaMax}")  # Snapshot del swap

            pivote: Numero = A[filaAct][colAct]  # Toma el valor del pivote (no se imprime)

            for i in range(filaAct + 1, nFilas):  # Recorre filas debajo del pivote
                valor: Numero = A[i][colAct]  # Valor a anular en la columna del pivote
                if valor == 0:  # Si ya es cero
                    continue  # No hace nada
                m: Numero = valor / pivote  # Calcula multiplicador m = A[i,k]/A[k,k]
                for j in range(colAct, nCols):  # Actualiza desde la columna del pivote hacia la derecha
                    A[i][j] -= m * A[filaAct][j]  # A[i,j] = A[i,j] - m*A[k,j]
                b[i] -= m * b[filaAct]  # Actualiza el término independiente correspondiente
                if Registro is not None:  # Si se registra
                    Registro.RegistrarMatrizAumentada(A, b, f"Eliminación en fila {i} con multiplicador {m}")  # Snapshot de la eliminación

            filaAct += 1  # Avanza a la siguiente fila para el próximo pivote
            colAct += 1  # Avanza a la siguiente columna

        rangoA: int = sum(not EliminadorGauss.EsFilaCero(fila) for fila in A)  # Calcula rango(A) internamente
        rangoAb: int = 0  # Inicializa rango([A|b])
        for i in range(nFilas):  # Recorre filas
            filaNula: bool = EliminadorGauss.EsFilaCero(A[i])  # ¿Fila de A es nula?
            rhsNoCero: bool = (b[i] != 0)  # ¿b[i] es no cero?
            if (not filaNula) or rhsNoCero:  # Si A[i,*] no es nula o b[i] ≠ 0
                rangoAb += 1  # Cuenta esta fila para el rango de la aumentada

        return ResultadoGauss(  # Devuelve lo necesario para clasificar y resolver
            MatrizTriangularSuperior=A,  # Matriz triangular superior final
            VectorTransformado=b,  # Vector b transformado
            RangoDeA=rangoA,  # Rango(A) (no se imprime)
            RangoDeAumentada=rangoAb  # Rango([A|b]) (no se imprime)
        )

    @staticmethod
    def SustitucionHaciaAtras(MatrizTri: List[List[Numero]], VectorTransf: List[Numero]) -> List[Numero]:
        """Resuelve Ux=y por sustitución hacia atrás (requiere pivotes diagonales no nulos)."""
        n: int = len(MatrizTri)  # Tamaño del sistema
        x: List[Numero] = [Fraction(0) for _ in range(n)]  # Vector solución inicializado
        for i in range(n - 1, -1, -1):  # Recorre desde la última fila a la primera
            suma: Numero = VectorTransf[i]  # Empieza con el RHS transformado
            for j in range(i + 1, n):  # Resta contribuciones conocidas U[i][j]*x[j]
                suma -= MatrizTri[i][j] * x[j]  # Actualiza la suma
            piv: Numero = MatrizTri[i][i]  # Toma el pivote diagonal
            if piv == 0:  # Si pivote es cero
                raise ValueError("Pivote cero en sustitución hacia atrás (no hay solución única).")  # Error de unicidad
            x[i] = suma / piv  # Calcula x[i]
        return x  # Devuelve solución exacta (fracciones)

# SISTEMA LINEAL

@dataclass
class SistemaLineal:
    MatrizCoeficientes: List[List[Numero]]  # Matriz A (coeficientes)
    VectorIndependientes: List[Numero]  # Vector b (términos independientes)
    NombresVariables: List[str]  # Lista ordenada de variables (x, y, z, x1, ...)

    @classmethod
    def DesdeEntradaDeEcuaciones(cls) -> SistemaLineal:
        """Lee ecuaciones en texto desde consola y construye el sistema lineal."""
        print("Introduce ecuaciones lineales (una por línea). Ej.:  2x - 3y + z = 5")  # Instrucción de uso
        print("Usa variables como x, y, z, x1, x2... y números enteros/decimales/fracciones (7/2).")  # Formato permitido
        print("Deja la línea en blanco para terminar.\n")  # Cómo finalizar la carga
        Ecuaciones: List[str] = []  # Lista para almacenar las ecuaciones ingresadas
        while True:  # Bucle de lectura
            Texto: str = input(f"Ecuación {len(Ecuaciones)+1}: ").strip()  # Pide una ecuación
            if Texto == "":  # Si está vacía
                break  # Termina la entrada

            # *** VALIDACIÓN AGREGADA ***
            ok, msg = _es_ecuacion_lineal_valida(Texto)
            if not ok:
                print(f"✗ Entrada inválida: {msg}\n")
                continue  # No se agrega la ecuación; se vuelve a pedir

            Ecuaciones.append(Texto)  # Agrega a la lista si pasó validación

        if not Ecuaciones:  # Si no se ingresó nada
            raise ValueError("No se ingresaron ecuaciones.")  # Lanza error
        A, b, Vars = AnalizadorEcuacionesTexto.AnalizarEcuaciones(Ecuaciones)  # Convierte ecuaciones a (A, b, variables)
        return cls(MatrizCoeficientes=A, VectorIndependientes=b, NombresVariables=Vars)  # Devuelve el sistema

    def DiagnosticarYResolver(self, Registro: Optional[RegistroPasos] = None) -> Tuple[str, str, Optional[Dict[str, Numero]]]:
        """Ejecuta Gauss, clasifica el sistema y retorna solución si es única. No imprime pivotes/rangos."""
        Res: ResultadoGauss = EliminadorGauss.EliminacionHaciaAdelante(self.MatrizCoeficientes, self.VectorIndependientes, Registro)  # Corre Gauss
        rA: int = Res.RangoDeA  # Toma rango(A) para clasificar internamente
        rAb: int = Res.RangoDeAumentada  # Toma rango([A|b]) para clasificar internamente
        m: int = len(self.MatrizCoeficientes[0]) if self.MatrizCoeficientes else 0  # Número de variables

        EsConsistente: bool = (rA == rAb)  # Criterio de consistencia (Rouché–Frobenius)
        TipoConsistencia: str = "consistente" if EsConsistente else "inconsistente"  # Etiqueta de consistencia

        if not EsConsistente:  # Si el sistema es inconsistente
            return TipoConsistencia, "sin_solucion", None  # No hay solución

        if rA == m:  # Si el rango de A es completo (igual al número de variables)
            x: List[Numero] = EliminadorGauss.SustitucionHaciaAtras(Res.MatrizTriangularSuperior, Res.VectorTransformado)  # Resuelve Ux=y
            Sol: Dict[str, Numero] = {self.NombresVariables[i]: x[i] for i in range(m)}  # Mapeo variable->valor
            return TipoConsistencia, "solucion_unica", Sol  # Devuelve solución única

        return TipoConsistencia, "infinitas_soluciones", None  # Consistente pero con variables libres: infinitas soluciones

    def MostrarMatrizAumentada(self) -> None:
        """Imprime [A|b] con el mismo formato alineado usado en el registro de pasos."""
        if not self.MatrizCoeficientes:  # Si no hay datos
            print("[] | []")  # Imprime vacío
            return  # Sale
        for Linea in GenerarLineasMatrizAumentada(self.MatrizCoeficientes, self.VectorIndependientes, Relleno=2, AnchoMinimo=2):  # Genera líneas
            print(Linea)  # Imprime cada línea
        print()  # Línea en blanco final

# UTILIDADES DE MENÚ Y PROGRAMA PRINCIPAL

def MostrarMenu() -> None:
    """Imprime el menú de opciones del programa."""
    print("\n===== MENÚ =====")  # Encabezado
    print("1) Resolver (automático, sin pasos)")  # Opción 1
    print("2) Resolver con pasos detallados (método de Gauss)")  # Opción 2
    print("4) Mostrar matriz aumentada [A|b]")  # Opción 4
    print("5) Salir")  # Opción 5

def LeerOpcionMenu() -> int:
    """Lee una opción válida del menú (solo 1, 2, 4 o 5)."""
    Validas = {1, 2, 4, 5}  # Conjunto de opciones permitidas
    while True:  # Bucle de validación
        Texto = input("Elige una opción [1,2,4,5]: ").strip()  # Pide la opción
        if Texto.isdigit():  # Verifica que sea numérica
            Opcion = int(Texto)  # Convierte a entero
            if Opcion in Validas:  # Comprueba que esté permitida
                return Opcion  # Devuelve la opción válida
        print("Opción inválida. Debe ser 1, 2, 4 o 5.")  # Mensaje de error

def Principal() -> None:
    """Punto de entrada del programa: lectura de ecuaciones, menú y acciones."""
    print("=== Calculadora de Sistemas Lineales (método de Gauss) ===\n")  # Título de la aplicación
    Sistema: SistemaLineal = SistemaLineal.DesdeEntradaDeEcuaciones()  # Construye el sistema a partir de ecuaciones en texto

    while True:  # Bucle del menú principal
        MostrarMenu()  # Muestra las opciones
        Opcion: int = LeerOpcionMenu()  # Lee una opción válida

        if Opcion == 1:  # Resolver sin mostrar pasos
            Registro: Optional[RegistroPasos] = None  # No creamos logger
            Consistencia, Tipo, Solucion = Sistema.DiagnosticarYResolver(Registro)  # Ejecuta Gauss
            print(f"\nClasificación del sistema: {Consistencia}")  # Muestra consistencia
            print(f"Tipo de solución: {Tipo}")  # Muestra tipo de solución
            if Solucion is not None:  # Si hubo solución única
                SolucionFloat: Dict[str, float] = {k: float(v) for k, v in Solucion.items()}  # Convierte a float para legibilidad
                print("Solución:", SolucionFloat)  # Imprime la solución

        elif Opcion == 2:  # Resolver con pasos detallados
            RegistroDetallado = RegistroPasos()  # Crea el registro de pasos
            Consistencia, Tipo, Solucion = Sistema.DiagnosticarYResolver(RegistroDetallado)  # Ejecuta Gauss registrando snapshots
            print(f"\nClasificación del sistema: {Consistencia}")  # Muestra consistencia
            print(f"Tipo de solución: {Tipo}")  # Muestra tipo
            print("\n--- PASOS DETALLADOS (Gauss) ---")  # Encabezado del bloque de pasos
            print(RegistroDetallado.ObtenerTexto())  # Imprime todos los estados [A|b] registrados (swaps y eliminaciones)
            print("--- FIN DE PASOS ---")  # Cierre del bloque
            if Solucion is not None:  # Si hubo solución única
                SolucionFloat: Dict[str, float] = {k: float(v) for k, v in Solucion.items()}  # Conversión a float
                print("Solución:", SolucionFloat)  # Imprime la solución

        elif Opcion == 4:  # Mostrar la matriz aumentada normalizada
            print("\nMatriz aumentada [A|b]:")  # Encabezado
            Sistema.MostrarMatrizAumentada()  # Muestra [A|b] con columnas alineadas

        elif Opcion == 5:  # Salir del programa
            print("\n¡Saliendo del programa!")  # Mensaje de despedida
            break  # Rompe el bucle y termina

if __name__ == "__main__":  # Si el archivo se ejecuta directamente (no importado como módulo)
    Principal()  # Llama al punto de entrada principal
