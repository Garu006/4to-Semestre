# -*- coding: utf-8 -*-
"""
eliminacion_3x3.py
Método de Eliminación (Reducción) para sistemas 3×3.

Incluye:
 - Resolución paso a paso con explicación estilo “cuaderno”.
 - Resolución rápida (solo solución).
 - Menú interactivo para pedir coeficientes.

Se permiten enteros, decimales y fracciones a/b en la entrada.
"""

from fractions import Fraction

# ───────────────────────── Utilidades ─────────────────────────

def format_fraction(value: Fraction) -> str:
    """Devuelve una fracción en formato compacto (a/b o entero si aplica)."""
    if isinstance(value, Fraction):
        return f"{value.numerator}/{value.denominator}" if value.denominator != 1 else f"{value.numerator}"
    return str(value)

def to_fraction(x) -> Fraction:
    """Convierte enteros, decimales o strings (incluye 'a/b' y comas) a Fraction."""
    if isinstance(x, Fraction):
        return x
    if isinstance(x, (int, float)):
        return Fraction(x).limit_denominator()
    t = str(x).strip().replace(",", ".")
    if "/" in t:
        n, d = t.split("/")
        return Fraction(int(n.strip()), int(d.strip()))
    return Fraction(t)

def _format_equation(a: Fraction, b: Fraction, c: Fraction, d: Fraction) -> str:
    """Devuelve 'ax + by + cz = d' con signos agradables a la vista."""
    def term(coeff: Fraction, var: str) -> str | None:
        if coeff == 0:
            return None
        mag = format_fraction(abs(coeff))
        if var == "x":
            # primer término: permite signo negativo inicial
            return f"{'- ' if coeff < 0 else ''}{mag}x"
        # términos posteriores: manejar +/-
        return f"{'+ ' if coeff > 0 else '- '}{mag}{var}"
    lhs_parts = [term(a, "x"), term(b, "y"), term(c, "z")]
    lhs_parts = [t for t in lhs_parts if t]
    lhs = " ".join(lhs_parts) if lhs_parts else "0"
    lhs = lhs if not lhs.startswith("+ ") else lhs[2:]
    return f"{lhs} = {format_fraction(d)}"

def _print_equation(label: str, row: list[Fraction]) -> None:
    """Imprime '(n) ax + by + cz = d'."""
    a, b, c, d = row
    print(f"({label}) {_format_equation(a, b, c, d)}")

# ───────────────── Resolución: Paso a Paso ─────────────────

def resolver_eliminacion_3x3_paso_a_paso(
    a11, a12, a13, d1,
    a21, a22, a23, d2,
    a31, a32, a33, d3
):
    """
    Resuelve por eliminación 3×3 explicando cada operación.
    Retorna (x, y, z) como Fraction.
    """
    # Ecuaciones iniciales como fracciones
    eq1 = [to_fraction(a11), to_fraction(a12), to_fraction(a13), to_fraction(d1)]
    eq2 = [to_fraction(a21), to_fraction(a22), to_fraction(a23), to_fraction(d2)]
    eq3 = [to_fraction(a31), to_fraction(a32), to_fraction(a33), to_fraction(d3)]

    print("\n=== Método de Eliminación 3×3 (estilo cuaderno) ===\n")
    print("Sistema inicial:")
    _print_equation("1", eq1)
    _print_equation("2", eq2)
    _print_equation("3", eq3)
    print()

    # Paso 1: eliminar y entre (1) y (2) → (4)
    print("Paso 1) Eliminar y combinando ecuaciones:")
    m1 = eq2[1]          # coeficiente de y en (2)
    m2 = -eq1[1]         # opuesto del coeficiente de y en (1)
    print(f"    (2) + ({format_fraction(m2)})·(1)  →  (4)")
    eq4 = [m1*eq1[i] + m2*eq2[i] for i in range(4)]
    _print_equation("4", eq4)
    print()

    # Paso 2: eliminar y entre (1) y (3) → (5)
    print("Paso 2) Repetimos para (1) y (3):")
    m1 = eq3[1]
    m2 = -eq1[1]
    print(f"    (3) + ({format_fraction(m2)})·(1)  →  (5)")
    eq5 = [m1*eq1[i] + m2*eq3[i] for i in range(4)]
    _print_equation("5", eq5)
    print()

    # Paso 3: resolver 2×2 (4) y (5) eliminando x → (6)
    print("Paso 3) Resolver el 2×2 (4) y (5) eliminando x:")
    m1 = eq5[0]          # coeficiente de x en (5)
    m2 = -eq4[0]         # opuesto del coeficiente de x en (4)
    print(f"    (5) + ({format_fraction(m2)})·(4)  →  (6)")
    eq6 = [m1*eq4[i] + m2*eq5[i] for i in range(4)]
    _print_equation("6", eq6)

    # De (6) obtener z
    if eq6[2] == 0:
        raise ValueError("No se pudo obtener pivote para z (sistema dependiente o sin solución).")
    z = eq6[3] / eq6[2]
    print(f"    De (6): z = {format_fraction(eq6[3])}/{format_fraction(eq6[2])} = {format_fraction(z)}\n")

    # Paso 4: sustituir z en (4) para hallar x
    if eq4[0] == 0:
        raise ValueError("No se pudo obtener pivote para x en (4).")
    x = (eq4[3] - eq4[2]*z) / eq4[0]
    print("Paso 4) Sustituir z en (4) para hallar x:")
    print(f"    x = ({format_fraction(eq4[3])} - {format_fraction(eq4[2])}·{format_fraction(z)}) / {format_fraction(eq4[0])} = {format_fraction(x)}\n")

    # Paso 5: sustituir x y z en (1) para hallar y
    if eq1[1] == 0:
        raise ValueError("No se pudo obtener pivote para y en (1).")
    y = (eq1[3] - eq1[0]*x - eq1[2]*z) / eq1[1]
    print("Paso 5) Sustituir x y z en (1) para hallar y:")
    print(f"    y = ({format_fraction(eq1[3])} - {format_fraction(eq1[0])}·{format_fraction(x)} - {format_fraction(eq1[2])}·{format_fraction(z)}) / {format_fraction(eq1[1])} = {format_fraction(y)}\n")

    print("=== Solución final ===")
    print(f"(x, y, z) = ({format_fraction(x)}, {format_fraction(y)}, {format_fraction(z)})")
    return x, y, z

# ──────────── Resolución: Solo Solución (rápida) ────────────

def resolver_eliminacion_3x3_solo_solucion(
    a11, a12, a13, d1,
    a21, a22, a23, d2,
    a31, a32, a33, d3
):
    """
    Resuelve por eliminación 3×3 (sin imprimir pasos).
    Retorna (x, y, z) como Fraction y muestra la solución.
    """
    eq1 = [to_fraction(a11), to_fraction(a12), to_fraction(a13), to_fraction(d1)]
    eq2 = [to_fraction(a21), to_fraction(a22), to_fraction(a23), to_fraction(d2)]
    eq3 = [to_fraction(a31), to_fraction(a32), to_fraction(a33), to_fraction(d3)]

    # Eliminar y → (4), (5)
    m1, m2 = eq2[1], -eq1[1]
    eq4 = [m1*eq1[i] + m2*eq2[i] for i in range(4)]
    m1, m2 = eq3[1], -eq1[1]
    eq5 = [m1*eq1[i] + m2*eq3[i] for i in range(4)]

    # Eliminar x → (6)
    m1, m2 = eq5[0], -eq4[0]
    eq6 = [m1*eq4[i] + m2*eq5[i] for i in range(4)]

    if eq6[2] == 0 or eq4[0] == 0 or eq1[1] == 0:
        raise ValueError("Sistema degenerado (sin pivotes adecuados).")

    z = eq6[3] / eq6[2]
    x = (eq4[3] - eq4[2]*z) / eq4[0]
    y = (eq1[3] - eq1[0]*x - eq1[2]*z) / eq1[1]

    print("\n=== Solución rápida (sin pasos) ===")
    print(f"(x, y, z) = ({format_fraction(x)}, {format_fraction(y)}, {format_fraction(z)})")
    return x, y, z

# ───────────────────────── Menú CLI ─────────────────────────

def pedir_coeficientes_usuario() -> tuple:
    """Solicita al usuario los coeficientes del sistema 3×3 (1 ecuación por línea)."""
    print("\nIngresa los coeficientes del sistema 3×3 (acepta enteros, decimales o fracciones a/b).")
    print("Ecuación (1): a11 x + a12 y + a13 z = d1")
    a11 = input("a11: "); a12 = input("a12: "); a13 = input("a13: "); d1 = input("d1: ")
    print("\nEcuación (2): a21 x + a22 y + a23 z = d2")
    a21 = input("a21: "); a22 = input("a22: "); a23 = input("a23: "); d2 = input("d2: ")
    print("\nEcuación (3): a31 x + a32 y + a33 z = d3")
    a31 = input("a31: "); a32 = input("a32: "); a33 = input("a33: "); d3 = input("d3: ")
    return a11, a12, a13, d1, a21, a22, a23, d2, a31, a32, a33, d3

def menu():
    """Menú interactivo del método de Eliminación 3×3."""
    while True:
        print("\n" + "="*55)
        print(" Calculadora – Método de Eliminación 3×3")
        print("="*55)
        print("1) Resolver 3×3 paso a paso")
        print("2) Resolver 3×3 solo solución")
        print("0) Salir")
        opcion = input("\nElige una opción: ").strip()

        if opcion == "1":
            try:
                coef = pedir_coeficientes_usuario()
                resolver_eliminacion_3x3_paso_a_paso(*coef)
            except Exception as e:
                print(f"\n⚠️ Entrada o cálculo inválido: {e}")
            input("\nPresiona Enter para continuar...")

        elif opcion == "2":
            try:
                coef = pedir_coeficientes_usuario()
                resolver_eliminacion_3x3_solo_solucion(*coef)
            except Exception as e:
                print(f"\n⚠️ Entrada o cálculo inválido: {e}")
            input("\nPresiona Enter para continuar...")

        elif opcion == "0":
            print("¡Hasta luego!")
            break
        else:
            print("Opción inválida.")

if __name__ == "__main__":
    menu()