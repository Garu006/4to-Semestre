# -*- coding: utf-8 -*-
"""
Gauss–Jordan n×n (solo matrices cuadradas) con fracciones exactas (sin NumPy).

• Entrada del tamaño: 'n x n' (p.ej. 3x3, 4x4). Si no es cuadrada, se rechaza.
• Paso a paso opcional (muestra operaciones y RREF).
• Resumen numérico: columnas pivote (números), valores de pivote, solución única
  o ejemplo numérico si hay infinitas; contradicción si es inconsistente.
• Verificadores de:
   - Forma escalonada (propiedades 1–3)
   - Forma escalonada reducida / RREF (propiedades 1–5)

Propiedades (según clase):
1) Las filas no nulas están arriba de las filas de ceros.
2) La entrada principal de cada fila está a la derecha de la de la fila superior.
3) Debajo de cada entrada principal hay ceros.
4) Cada entrada principal es 1.
5) Cada entrada principal 1 es la única entrada ≠0 en su columna.
"""

from __future__ import annotations
from dataclasses import dataclass
from fractions import Fraction
from typing import List, Optional, Tuple, Union
import re

Numero = Union[str, int, float, Fraction]

# ───────────── Utilidades ─────────────

def to_frac(x: Numero) -> Fraction:
    if isinstance(x, Fraction): return x
    if isinstance(x, (int, float)): return Fraction(x).limit_denominator()
    t = str(x).strip().replace(",", ".")
    if "/" in t:
        n, d = t.split("/", 1)
        return Fraction(int(n.strip()), int(d.strip()))
    if t in ("", "+", "-"):
        return Fraction(0, 1)
    return Fraction(t)

def q(fr: Fraction) -> str:
    return f"{fr.numerator}/{fr.denominator}" if fr.denominator != 1 else f"{fr.numerator}"

def fmt_aug(A: List[List[Fraction]], pivots: Optional[List[Tuple[int, int]]] = None) -> str:
    """Imprime la matriz aumentada alineada; marca pivotes con [1]."""
    r, c = len(A), len(A[0])
    mark = {(i, j) for (i, j) in (pivots or [])}
    cols_w = [0] * c
    for i in range(r):
        for j in range(c):
            txt = " [1] " if (i, j) in mark else q(A[i][j])
            cols_w[j] = max(cols_w[j], len(txt))
    lines = []
    for i in range(r):
        left = []
        for j in range(c - 1):
            txt = " [1] " if (i, j) in mark else q(A[i][j])
            left.append(txt.rjust(cols_w[j]))
        right = ("|" + q(A[i][c - 1]).rjust(cols_w[c - 1] + 1))
        lines.append("[ " + " ".join(left) + " " + right + " ]")
    return "\n".join(lines)

# ───────── Verificadores de ESCALONADA y RREF (1–5) ─────────

def es_escalonada(A: List[List[Fraction]]) -> bool:
    """
    Verifica 1–3 sobre la parte de coeficientes (todas menos la última columna).
    1) filas de ceros al final; 2) entradas principales avanzan a la derecha; 3) ceros debajo.
    """
    m, n = len(A), len(A[0]) - 1
    lead_prev = -1
    for i in range(m):
        # índice de la primera entrada ≠0 en la fila i (solo coeficientes)
        j = next((j for j in range(n) if A[i][j] != 0), None)
        if j is None:
            # fila cero: todas las siguientes deben ser cero en coeficientes
            if any(A[k][t] != 0 for k in range(i+1, m) for t in range(n)):
                return False
            return True  # el resto son ceros ⇒ ya cumple 1)
        # 2) avanza a la derecha
        if j <= lead_prev:
            return False
        lead_prev = j
        # 3) ceros debajo de la entrada principal
        for k in range(i+1, m):
            if A[k][j] != 0:
                return False
    return True

def es_rref(A: List[List[Fraction]]) -> bool:
    """
    Verifica 1–5 (RREF) sobre la parte de coeficientes:
    4) pivote = 1; 5) en su columna, arriba y abajo todo es 0.
    """
    if not es_escalonada(A):
        return False
    m, n = len(A), len(A[0]) - 1
    # localizar pivotes por fila
    for i in range(m):
        j = next((j for j in range(n) if A[i][j] != 0), None)
        if j is None:
            continue
        # 4) pivote es 1
        if A[i][j] != 1:
            return False
        # 5) única entrada ≠0 en su columna
        for k in range(m):
            if k != i and A[k][j] != 0:
                return False
    return True

# ───────── Resultado ─────────

@dataclass
class Resultado:
    pasos: List[str]
    rref: List[List[Fraction]]                    # matriz final (RREF)
    pivotes: List[Tuple[int, int]]                # (fila, col) de cada pivote
    columnas_pivote: List[int]                    # columnas pivote (1-indexed)
    columnas_libres: List[int]                    # columnas libres (1-indexed)
    solucion: Optional[List[Fraction]]            # si única
    clasificacion: str                            # 'consistente única' / 'consistente infinitas' / 'inconsistente'
    contradiccion: Optional[Fraction] = None
    nota: str = ""

# ───────── Operaciones elementales (con logging) ─────────

def swap(A, i, j, pasos, pivots):
    if i == j: return
    A[i], A[j] = A[j], A[i]
    pasos.append(f"Intercambio: R{i+1} ↔ R{j+1}")
    pasos.append(fmt_aug(A, pivots) + "\n")

def scale(A, i, k: Fraction, from_col: int, pasos, pivots):
    if k == 1: return
    for c in range(from_col, len(A[0])):
        A[i][c] *= k
    pasos.append(f"Escalo: R{i+1} ← {q(k)}·R{i+1}")
    pasos.append(fmt_aug(A, pivots) + "\n")

def addmul(A, dst, src, k: Fraction, from_col: int, pasos, pivots):
    if k == 0: return
    for c in range(from_col, len(A[0])):
        A[dst][c] += k * A[src][c]
    sgn = "+" if k >= 0 else "-"
    pasos.append(f"Fila: R{dst+1} ← R{dst+1} {sgn} {q(abs(k))}·R{src+1}")
    pasos.append(fmt_aug(A, pivots) + "\n")

# ───────── Gauss–Jordan ─────────

def gauss_jordan(A: List[List[Fraction]], registrar_pasos: bool = True) -> Resultado:
    """
    A: matriz aumentada n×(n+1) (coeficientes | independiente).
    Devuelve RREF + diagnóstico + datos para resumen.
    """
    pasos: List[str] = []
    pivots: List[Tuple[int, int]] = []

    if registrar_pasos:
        pasos.append("Matriz aumentada inicial:\n" + fmt_aug(A, pivots) + "\n")

    n = len(A)                    # cuadrada ⇒ m = n
    col = 0

    for r in range(n):
        if col >= n: break

        # buscar pivote ≠ 0 en esta columna
        piv = None
        for i in range(r, n):
            if A[i][col] != 0:
                piv = i
                break

        if piv is None:
            col += 1
            r -= 1
            continue

        if piv != r:
            swap(A, r, piv, pasos, pivots)

        val = A[r][col]
        if val != 1:
            scale(A, r, Fraction(1, 1) / val, col, pasos, pivots)

        pivots.append((r, col))
        if registrar_pasos:
            pasos.append(f"Pivote normalizado en columna {col+1}.")
            pasos.append(fmt_aug(A, pivots) + "\n")

        # hacer ceros arriba/abajo del pivote
        for i in range(n):
            if i == r: continue
            factor = -A[i][col]
            if factor != 0:
                addmul(A, i, r, factor, col, pasos, pivots)

        col += 1

    # inconsistente: [0 … 0 | b≠0]
    for i in range(n):
        if all(A[i][j] == 0 for j in range(n)) and A[i][n] != 0:
            nota = "Sistema inconsistente (0 = b≠0)."
            if registrar_pasos: pasos.append("Diagnóstico: " + nota + "\n")
            cols_piv = sorted({j for (_, j) in pivots})
            cols_lib = [j for j in range(n) if j not in cols_piv]
            return Resultado(
                pasos=pasos,
                rref=[row[:] for row in A],
                pivotes=pivots,
                columnas_pivote=[j+1 for j in cols_piv],
                columnas_libres=[j+1 for j in cols_lib],
                solucion=None,
                clasificacion="inconsistente",
                contradiccion=A[i][n],
                nota=nota,
            )

    # rango y columnas pivote/libres
    cols_piv = sorted({j for (_, j) in pivots})
    cols_lib = [j for j in range(n) if j not in cols_piv]
    rango = len(cols_piv)

    # consistente con infinitas si rango < n
    if rango < n:
        nota = "Sistema consistente con infinitas soluciones."
        if registrar_pasos: pasos.append("Diagnóstico: " + nota + "\n")
        return Resultado(
            pasos=pasos,
            rref=[row[:] for row in A],
            pivotes=pivots,
            columnas_pivote=[j+1 for j in cols_piv],
            columnas_libres=[j+1 for j in cols_lib],
            solucion=None,
            clasificacion="consistente infinitas",
            nota=nota,
        )

    # única solución: última columna por columnas pivote
    sol = [Fraction(0) for _ in range(n)]
    for i in range(n):
        pj = next((j for j in range(n) if A[i][j] == 1 and all(A[i][k] == 0 for k in range(j))), None)
        if pj is not None:
            sol[pj] = A[i][n]

    if registrar_pasos:
        pasos.append("RREF final:\n" + fmt_aug(A, pivots) + "\n")
        pasos.append("Solución única: (" + ", ".join(q(x) for x in sol) + ")\n")

    return Resultado(
        pasos=pasos,
        rref=[row[:] for row in A],
        pivotes=pivots,
        columnas_pivote=[j+1 for j in cols_piv],
        columnas_libres=[j+1 for j in cols_lib],
        solucion=sol,
        clasificacion="consistente única",
    )

# ───────── Entrada (solo CUADRADAS) ─────────

def pedir_dimensiones_cuadrada() -> int:
    """
    Lee un tamaño 'n x n' y exige que sea cuadrada.
    Acepta 'nxn' o 'n x n' (con X/x). Repite hasta ser válido.
    """
    patron = re.compile(r"^\s*(\d+)\s*[xX]\s*(\d+)\s*$")
    while True:
        s = input("Tamaño del sistema (n x n, p.ej. 3x3 o 4x4): ").strip()
        m_n = patron.match(s)
        if m_n:
            n1, n2 = int(m_n.group(1)), int(m_n.group(2))
            if n1 > 0 and n1 == n2:
                return n1
        print("Entrada inválida. Solo se permiten matrices CUADRADAS: usa 'n x n' con n>0 (ej. 3x3).")

def pedir_coeficientes_n(n: int) -> List[List[Fraction]]:
    """
    Pide n ecuaciones con n coeficientes cada una y su término independiente.
    Devuelve la matriz aumentada n×(n+1).
    """
    print("\nIngresa coeficientes (enteros, decimales o fracciones a/b).")
    A: List[List[Fraction]] = []
    for i in range(n):
        print(f"\nFila {i+1}:  " + " + ".join([f"a{i+1}{j+1}·x{j+1}" for j in range(n)]) + f" = b{i+1}")
        fila = []
        for j in range(n):
            fila.append(to_frac(input(f"a{i+1}{j+1}: ")))
        fila.append(to_frac(input(f"b{i+1}: ")))
        A.append(fila)
    return A

# ───────── Resumen numérico ─────────

def mostrar_resumen(res: Resultado) -> None:
    A = res.rref
    m, ctot = len(A), len(A[0])
    n = ctot - 1

    # Pivotes (más numérico)
    print("\n— Pivotes —")
    if res.columnas_pivote:
        valores_pivote = [q(A[i][j]) for (i, j) in res.pivotes]  # normalmente 1
        print("  Columnas pivote (número):", ", ".join(str(c) for c in res.columnas_pivote))
        print("  Valores en pivote:", ", ".join(valores_pivote))
    else:
        print("  (no hubo pivotes)")

    # Variables libres (más claro)
    print("\n— Variables libres (por índice) —")
    print(" ", ", ".join(str(c) for c in res.columnas_libres) or "—")

    # Forma escalonada / reducida
    print("\n— Forma —")
    print("  Escalonada: sí")
    print("  Escalonada reducida (RREF): sí" if res.clasificacion != "inconsistente" else "  Escalonada reducida (RREF): —")

    # Clasificación
    print("\n— Clasificación —")
    print(" ", res.clasificacion)
    if res.clasificacion == "inconsistente" and res.contradiccion is not None:
        print("  Fila contradictoria: 0 … 0 |", q(res.contradiccion))

    # Solución única
    if res.clasificacion == "consistente única" and res.solucion is not None:
        print("\n— Solución única —")
        print("  (" + ", ".join(q(x) for x in res.solucion) + ")")

    # Infinitas: ejemplo numérico con libres=0
    if res.clasificacion == "consistente infinitas":
        ejemplo = [Fraction(0) for _ in range(n)]
        col_piv_a_fila = {j: i for (i, j) in res.pivotes}
        for j in range(n):
            if (j + 1) in res.columnas_libres:   # libre ⇒ valor elegido (0)
                ejemplo[j] = Fraction(0)
            else:                                # básica ⇒ toma el independiente
                i = col_piv_a_fila[j]
                ejemplo[j] = A[i][n]
        print("\n— Ejemplo de solución (libres = 0) —")
        print("  (" + ", ".join(q(x) for x in ejemplo) + ")")

# ───────── Menú ─────────

def resolver_paso_a_paso() -> None:
    n = pedir_dimensiones_cuadrada()
    A = pedir_coeficientes_n(n)
    res = gauss_jordan(A, registrar_pasos=True)
    print("\n=== Procedimiento (paso a paso) ===\n")
    for linea in res.pasos:
        print(linea)
    mostrar_resumen(res)

def resolver_solo_solucion() -> None:
    n = pedir_dimensiones_cuadrada()
    A = pedir_coeficientes_n(n)
    res = gauss_jordan(A, registrar_pasos=False)
    mostrar_resumen(res)

def menu() -> None:
    while True:
        print("\n" + "=" * 60)
        print("  Gauss–Jordan n×n (fracciones exactas)")
        print("=" * 60)
        print("1) Resolver (paso a paso)")
        print("2) Resolver (solo solución)")
        print("3) Salir")
        op = input("Elige una opción: ").strip()
        if op == "1":
            resolver_paso_a_paso()
            input("\nPresiona Enter para continuar...")
        elif op == "2":
            resolver_solo_solucion()
            input("\nPresiona Enter para continuar...")
        elif op == "3":
            print("¡Hasta luego!")
            break
        else:
            print("Opción inválida.")

if __name__ == "__main__":
    menu()
