# -*- coding: utf-8 -*-
"""
Menú principal – Proyecto Álgebra Lineal
-----------------------------------------
Este archivo gestiona el menú principal del proyecto, desde donde se accede
a todos los módulos disponibles para resolver sistemas de ecuaciones lineales
y otros métodos numéricos.

Ejecución recomendada:
    python Algebra-Lineal/main/mainmenu.py
O, desde la raíz del repositorio:
    python -m Algebra-Lineal.main.mainmenu
"""

from pathlib import Path
import sys, os, time

# ────────────────────────────────
# CONFIGURACIÓN DE RUTAS (IMPORTS)
# ────────────────────────────────
# Hacemos visible la carpeta raíz "Algebra-Lineal" para poder importar módulos
RUTA_BASE = Path(__file__).resolve().parents[1]  
if str(RUTA_BASE) not in sys.path:
    sys.path.insert(0, str(RUTA_BASE))

# ────────────────────────────────
# CONFIGURACIÓN DE COLORES (OPCIONAL)
# ────────────────────────────────
# Usamos colorama para darle estilo a los textos de la terminal.
# Si no está instalada, el programa seguirá funcionando en blanco y negro.
try:
    from colorama import init as _cinit, Fore, Style
    _cinit(autoreset=True)
    C1, C2, C3 = Fore.CYAN, Fore.MAGENTA, Fore.GREEN  # Colores para títulos, secciones y opciones
    CERR = Fore.RED                                   # Mensajes de error
    BOLD, RESET = Style.BRIGHT, Style.RESET_ALL
except Exception:
    # Si colorama no está disponible, trabajamos sin colores
    C1 = C2 = C3 = CERR = BOLD = RESET = ""

# ────────────────────────────────
# IMPORTACIÓN DE MÓDULOS (FUNCIONES)
# ────────────────────────────────

# Métodos para sistemas 2x2
from dos_por_dos.igualacion import menu as run_igualacion
from dos_por_dos.Funcion_Sustitucion import main as run_sustitucion

# Método de eliminación/reducción 2x2
try:
    from Eliminación_2x2.Reduccion import main as run_eliminacion
except Exception:
    run_eliminacion = None  # Si no está disponible, el menú lo manejará

# Método de eliminación 3x3
try:
    from tres_por_tres.Funcion_Eliminacion3x3 import menu as run_elim3
except Exception:
    run_elim3 = None  # Si no está disponible, el menú lo manejará

# Método gráfico 2x2 (basado en Cramer)
from sistemas2x2.main import resolver_interactivo as run_grafico
from sistemas2x2.parsing import ParseError  

# Otros métodos adicionales (ej. Gauss)
try:
    from MetodoGauss.GaussBeta import Principal as run_gauss
except Exception:
    run_gauss = None


# ────────────────────────────────
# FUNCIONES AUXILIARES DE INTERFAZ
# ────────────────────────────────

def limpiar_pantalla():
    """Limpia la terminal según el sistema operativo."""
    os.system("cls" if os.name == "nt" else "clear")

def cabecera(titulo: str):
    """Imprime un encabezado formateado para secciones o menús."""
    barra = "═" * 60
    print(f"{C1}{BOLD}╔{barra}╗{RESET}")
    print(f"{C1}{BOLD}║{RESET} {BOLD}{titulo:<58}{C1}{BOLD}║{RESET}")
    print(f"{C1}{BOLD}╚{barra}╝{RESET}")

def banner():
    """Imprime el encabezado principal del programa."""
    cabecera("ÁLGEBRA LINEAL – MENÚ PRINCIPAL")

def pausar(msg="Presiona ENTER para continuar…"):
    """Pausa la ejecución para que el usuario pueda leer la salida."""
    try:
        input(f"\n{msg}")
    except KeyboardInterrupt:
        # Si el usuario presiona Ctrl+C, evitamos que el programa se detenga abruptamente
        print()
        return

def pedir_opcion(validas):
    """
    Solicita al usuario elegir una opción válida del menú.
    Repite la pregunta hasta que se ingrese un número permitido.
    """
    while True:
        op = input(f"{C3}{BOLD}Seleccione una opción ➜ {RESET}").strip()
        if op.isdigit() and int(op) in validas:
            return int(op)
        print(f"{CERR}→ Opción inválida.{RESET}")

def ejecutar(func, nombre: str):
    """
    Ejecuta un subprograma.  
    Si el módulo no está disponible o falla, muestra un mensaje de error.
    """
    limpiar_pantalla()
    cabecera(nombre)
    if func is None:
        print(f"{CERR}Módulo no disponible o mal importado.{RESET}")
        pausar()
        return
    try:
        func()  # Llamamos al subprograma correspondiente
    except KeyboardInterrupt:
        print(f"\n{CERR}Interrumpido por el usuario.{RESET}")
    except Exception as e:
        print(f"{CERR} Error al ejecutar {nombre}:{RESET}\n{repr(e)}")
    finally:
        pausar()

# ────────────────────────────────
# SUBMENÚS DEL PROGRAMA
# ────────────────────────────────
def submenu_2x2():
    while True:
        limpiar_pantalla()
        cabecera("Sistemas 2x2")
        print(f"{C3}1){RESET} Igualación")
        print(f"{C3}2){RESET} Sustitución")
        print(f"{C3}3){RESET} Eliminación / Reducción")
        print(f"{C3}4){RESET} Método gráfico (con Cramer)")
        print(f"{C3}0){RESET} Volver\n")
        op = pedir_opcion({0,1,2,3,4})

        if op == 1: ejecutar(run_igualacion, "Igualación 2x2")
        elif op == 2: ejecutar(run_sustitucion, "Sustitución 2x2")
        elif op == 3: ejecutar(run_eliminacion, "Eliminación / Reducción 2x2")
        elif op == 4: ejecutar(run_grafico, "Método gráfico 2x2")
        else: return

def submenu_3x3():
    """Incluye Gauss–Jordan (si existe) y Eliminación 3x3."""
    while True:
        limpiar_pantalla()
        cabecera("Sistemas 3x3")
        # Import dinámico por si el archivo cambia de nombre entre ramas
        try:
            from tres_por_tres.Funcion_Gauss_jordan import menu as run_gj
        except Exception:
            run_gj = None

        print(f"{C3}1){RESET} Gauss–Jordan")
        print(f"{C3}2){RESET} Eliminación / Reducción 3x3") 
        print(f"{C3}0){RESET} Volver\n")
        op = pedir_opcion({0,1,2})

        if op == 1: ejecutar(run_gj, "Gauss–Jordan 3x3")
        elif op == 2: ejecutar(run_elim3, "Eliminación 3x3")
        else: return

def submenu_otros():
    while True:
        limpiar_pantalla()
        cabecera("Métodos adicionales")
        print(f"{C3}1){RESET} Método de Gauss (GaussBeta)")
        print(f"{C3}0){RESET} Volver\n")
        op = pedir_opcion({0,1})
        if op == 1: ejecutar(run_gauss, "Método de Gauss")
        else: return

# ───────────────────── Loop principal ─────────────────────
def main():
    while True:
        banner()
        print(f"{C3}1){RESET} Sistemas 2x2")
        print(f"{C3}2){RESET} Sistemas 3x3")
        print(f"{C3}3){RESET} Otros métodos")
        print(f"{C3}0){RESET} Salir\n")

        op = pedir_opcion({0,1,2,3})
        if op == 1: submenu_2x2()
        elif op == 2: submenu_3x3()
        elif op == 3: submenu_otros()
        else:
            limpiar_pantalla()
            print(f"{BOLD}¡Hasta luego!{RESET}")
            time.sleep(0.4)
            break

if __name__ == "__main__":
    main()
