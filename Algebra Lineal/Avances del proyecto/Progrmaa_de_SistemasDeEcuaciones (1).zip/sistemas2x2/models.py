
from __future__ import annotations
from dataclasses import dataclass
from fractions import Fraction
from typing import Optional, Tuple


from .parsing import convertir_ecuacion


@dataclass(frozen=True)
class EcuacionLineal:
    A: Fraction 
    B: Fraction
    C: Fraction

    @classmethod
    def from_string(cls, s: str) -> EcuacionLineal:
        A,B,C = convertir_ecuacion(s)
        return cls(A,B,C)
    
    #propiedades para el metodo grafico

    def es_vertical(self) -> bool:
        return self.B == 0
    
    def es_horizontal(self) -> bool:
        return self.A == 0

    def pendiente(self) -> Optional[Fraction]:
        """Pendiente m. None si la recta es vertical."""
        if self.B == 0:
            return None
        return -self.A / self.B
    
    def y_intercepto(self) -> Optional[Fraction]:
        if self.B == 0:
            return None
        return self.C / self.B

    def x_intercepto(self) -> Optional[Fraction]:
        if self.A == 0:
            return None
        return self.C / self.A
    
    def forma_canonica(self) -> str:
        def f(fr: Fraction) -> str:
            return str(fr) if fr.denominator != 1 else str(fr.numerator)
        return f"{f(self.A)}x + {f(self.B)}y = {f(self.C)}"
    

@dataclass(frozen=True)
class Sistema2x2:
  #Par de ecuaciones lineales en dos variables.
    e1: EcuacionLineal
    e2: EcuacionLineal

    def determinante(self) -> Fraction:
        return self.e1.A * self.e2.B - self.e2.A * self.e1.B

    def clasificacion(self) -> str:
        """Clasifica el sistema: única, sin solución o infinitas."""
        det = self.determinante()
        if det != 0:
            return "unica solución (rectas secantes)"
        A1, B1, C1 = self.e1.A, self.e1.B, self.e1.C
        A2, B2, C2 = self.e2.A, self.e2.B, self.e2.C
        # Proporcionalidad por productos cruzados (evita dividir por 0)
        if A1 * B2 == A2 * B1 and A1 * C2 == A2 * C1 and B1 * C2 == B2 * C1:
            return "infinitas soluciones (rectas coincidentes)"
        return "sin solución (rectas paralelas)"
    
    def interseccion(self) -> Optional[Tuple[Fraction, Fraction]]:
        """Devuelve (x, y) por Cramer si det ≠ 0; si no, None."""
        det = self.determinante()
        if det == 0:
            return None
        x = (self.e1.C * self.e2.B - self.e2.C * self.e1.B) / det
        y = (self.e1.A * self.e2.C - self.e2.A * self.e1.C) / det
        return x, y




