"""main.py — Interfaz de línea de comandos para el sistema 2x2.

Modos de salida:
1) Rápido (solo la respuesta + puntos e info para graficar)
2) Paso a paso (procedimiento completo)

Uso:
$ python main.py
"""

# sistemas2x2/main.py
from __future__ import annotations
from fractions import Fraction
from typing import Optional, Tuple, List

# ---- IMPORTS que funcionan en los dos modos (paquete o script suelto) ----
try:
    # Modo paquete: llamado desde el menú -> relative imports
    from .parsing import ParseError
    from .models import EcuacionLineal, Sistema2x2
except Exception:
    # Modo script directo: python sistemas2x2/main.py
    import sys, pathlib
    PKG_ROOT = pathlib.Path(__file__).resolve().parents[1]  # .../Algebra-Lineal
    if str(PKG_ROOT) not in sys.path:
        sys.path.insert(0, str(PKG_ROOT))
    # Ahora imports absolutos
    from sistemas2x2.parsing import ParseError
    from sistemas2x2.models import EcuacionLineal, Sistema2x2


# ======== Soporte opcional de 'rich' para una CLI más bonita ========
try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.prompt import Prompt
    from rich import box
    _RICH = True
    console = Console()
except Exception:
    _RICH = False
    console = None  # type: ignore


# ===== utilidades de impresión =====
def _fmt(fr: Optional[Fraction]) -> str:
    if fr is None:
        return "—"
    return str(fr) if fr.denominator != 1 else str(fr.numerator)

def _print_title(text: str) -> None:
    if _RICH:
        console.rule(f"[bold cyan]{text}")
    else:
        print("\n" + "=" * 8, text, "=" * 8)

def _print_panel(title: str, body: str) -> None:
    if _RICH:
        console.print(Panel(body, title=title, border_style="cyan"))
    else:
        print(f"\n[{title}]")
        print(body)

def _make_points(eq: EcuacionLineal) -> List[Tuple[Fraction, Fraction]]:
    """Devuelve dos puntos recomendados para trazar la recta."""
    pts: List[Tuple[Fraction, Fraction]] = []
    xi, yi = eq.x_intercepto(), eq.y_intercepto()
    if xi is not None:
        pts.append((xi, Fraction(0)))
    if yi is not None:
        pts.append((Fraction(0), yi))
    if len(pts) < 2:
        if eq.es_vertical():
            pts.append((xi if xi is not None else Fraction(0), Fraction(1)))
        elif eq.es_horizontal():
            pts.append((Fraction(1), yi if yi is not None else Fraction(0)))
        else:
            m = eq.pendiente()
            b = eq.y_intercepto()
            x_alt = Fraction(1)
            y_alt = m * x_alt + b  # y = mx + b
            pts.append((x_alt, y_alt))
    return pts[:2]

def _print_points_table(pts1: List[Tuple[Fraction, Fraction]], pts2: List[Tuple[Fraction, Fraction]]) -> None:
    if _RICH:
        table = Table(title="Puntos sugeridos", box=box.SIMPLE_HEAVY)
        table.add_column("Recta", justify="center", style="bold")
        table.add_column("P1 (x, y)", justify="center")
        table.add_column("P2 (x, y)", justify="center")
        table.add_row(
            "1",
            f"({_fmt(pts1[0][0])}, {_fmt(pts1[0][1])})",
            f"({_fmt(pts1[1][0])}, {_fmt(pts1[1][1])})",
        )
        table.add_row(
            "2",
            f"({_fmt(pts2[0][0])}, {_fmt(pts2[0][1])})",
            f"({_fmt(pts2[1][0])}, {_fmt(pts2[1][1])})",
        )
        console.print(table)
    else:
        print("\nPuntos sugeridos:")
        print(f"  Recta 1: ({_fmt(pts1[0][0])}, {_fmt(pts1[0][1])}), ({_fmt(pts1[1][0])}, {_fmt(pts1[1][1])})")
        print(f"  Recta 2: ({_fmt(pts2[0][0])}, {_fmt(pts2[0][1])}), ({_fmt(pts2[1][0])}, {_fmt(pts2[1][1])})")

def _print_line_info(e1: EcuacionLineal, e2: EcuacionLineal) -> None:
    if _RICH:
        table = Table(title="Datos para graficar", box=box.SIMPLE_HEAVY)
        table.add_column("Recta", justify="center", style="bold")
        table.add_column("Pendiente m", justify="center")
        table.add_column("Corte en x", justify="center")
        table.add_column("Corte en y", justify="center")
        for i, eq in enumerate((e1, e2), start=1):
            table.add_row(
                str(i),
                _fmt(eq.pendiente()),
                _fmt(eq.x_intercepto()),
                _fmt(eq.y_intercepto()),
            )
        console.print(table)
    else:
        print("\nDatos para graficar:")
        for i, eq in enumerate((e1, e2), start=1):
            print(f"  Recta {i}: m={_fmt(eq.pendiente())} | x₀={_fmt(eq.x_intercepto())} | y₀={_fmt(eq.y_intercepto())}")


# ===== entrada de usuario =====
def pedir_ecuacion(n: int) -> EcuacionLineal:
    """Solicita al usuario la ecuación n y la valida; devuelve EcuacionLineal."""
    while True:
        if _RICH:
            prompt = f"[bold]Ingresa la ecuación {n}[/] (ej: [cyan]2x + 3y = 6[/]; admite x/y o x1/x2 y fracciones 3/4): "
            s = Prompt.ask(prompt)
        else:
            s = input(f"Ingresa la ecuación {n} (ej: 2x + 3y = 6; admite x/y o x1/x2 y fracciones 3/4): ").strip()
        try:
            return EcuacionLineal.from_string(s)
        except ParseError as e:
            _print_panel("Error de formato", str(e))
        except Exception as e:
            _print_panel("Error inesperado", str(e))

def pedir_modo_salida() -> str:
    """Pregunta al usuario el modo de salida y devuelve 'rapido' o 'pasos'."""
    while True:
        if _RICH:
            _print_panel(
                "Modo de salida",
                "1) Rápido (solo respuesta + puntos)\n2) Paso a paso (procedimiento completo)"
            )
            op = Prompt.ask("Opción", choices=["1", "2"], default="1")
        else:
            print("\nElige modo de salida:\n  1) Rápido (solo respuesta + puntos)\n  2) Paso a paso")
            op = input("Opción [1/2]: ").strip()
        if op == "1":
            return "rapido"
        if op == "2":
            return "pasos"
        _print_panel("Aviso", "Opción inválida. Intenta de nuevo.")


# ===== salidas =====
def salida_rapida(e1: EcuacionLineal, e2: EcuacionLineal, system: Sistema2x2) -> None:
    _print_title("Resultado")
    clas = system.clasificacion()
    _print_panel("Clasificación", clas)

    # Si hay solución única, muéstrala
    if ("unica" in clas) or ("única" in clas):
        xy = system.interseccion()
        assert xy is not None
        x, y = xy
        _print_panel("Solución", f"x = {_fmt(x)}\ny = {_fmt(y)}")

    # Siempre mostrar info para graficar y puntos sugeridos
    _print_line_info(e1, e2)
    pts1 = _make_points(e1)
    pts2 = _make_points(e2)
    _print_points_table(pts1, pts2)


def salida_paso_a_paso(e1: EcuacionLineal, e2: EcuacionLineal, system: Sistema2x2) -> None:
    _print_title("Paso a paso")

    # 1) Forma canónica
    body = f"Ecuación 1: {e1.forma_canonica()}\nEcuación 2: {e2.forma_canonica()}"
    _print_panel("1) Forma canónica (Ax + By = C)", body)

    # 2) Matriz de coeficientes y determinante
    A1, B1, C1 = e1.A, e1.B, e1.C
    A2, B2, C2 = e2.A, e2.B, e2.C
    det = system.determinante()
    mat = (
        f"| {_fmt(A1):>3}  {_fmt(B1):>3} |   | x |   =   | {_fmt(C1):>3} |\n"
        f"| {_fmt(A2):>3}  {_fmt(B2):>3} |   | y |   =   | {_fmt(C2):>3} |"
    )
    _print_panel("2) Matriz y determinante", mat + f"\n\ndet = A1*B2 - A2*B1 = {_fmt(A1)}*{_fmt(B2)} - {_fmt(A2)}*{_fmt(B1)} = {_fmt(det)}")

    # 3) Clasificación
    clas = system.clasificacion()
    _print_panel("3) Clasificación del sistema", clas)

    # 4) Cramer (si aplica)
    if det != 0:
        Dx = C1 * B2 - C2 * B1
        Dy = A1 * C2 - A2 * C1
        pasos = (
            f"Dx = C1*B2 - C2*B1 = {_fmt(C1)}*{_fmt(B2)} - {_fmt(C2)}*{_fmt(B1)} = {_fmt(Dx)}\n"
            f"Dy = A1*C2 - A2*C1 = {_fmt(A1)}*{_fmt(C2)} - {_fmt(A2)}*{_fmt(C1)} = {_fmt(Dy)}\n"
            f"x = Dx/det = {_fmt(Dx)}/{_fmt(det)}\n"
            f"y = Dy/det = {_fmt(Dy)}/{_fmt(det)}"
        )
        x, y = system.interseccion()  # type: ignore
        _print_panel("4) Regla de Cramer", pasos + f"\n\n⇒ Solución: x={_fmt(x)}, y={_fmt(y)}")

    # 5) Datos para graficar
    _print_line_info(e1, e2)

    # 6) Puntos sugeridos
    pts1 = _make_points(e1)
    pts2 = _make_points(e2)
    _print_points_table(pts1, pts2)

# ===== programa principal =====
def main() -> None:
    _print_title("Sistema lineal 2x2 (método gráfico, entrada validada)")
    e1 = pedir_ecuacion(1)
    e2 = pedir_ecuacion(2)
    system = Sistema2x2(e1, e2)

    modo = pedir_modo_salida()
    if modo == "rapido":
        salida_rapida(e1, e2, system)
    else:
        salida_paso_a_paso(e1, e2, system)


def resolver_interactivo():
    """Punto de entrada para que el menú general llame este módulo."""
    main()


if __name__ == "__main__":
    main()
