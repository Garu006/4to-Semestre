
# permite usar tipos qu eno existen aun
from __future__ import annotations
#fracciones lol 

from fractions import Fraction  

# permite trabajka rocn cadenaas de manera avanzasa 
import re 

FORMATO = str.maketrans("₀₁₂₃₄₅₆₇₈₉", "0123456789")

#excepcion cuando la cadena no cumple el formato 

class ParseError(Exception):
    pass


def to_fraction(num_string: str):
    #string a fraccion
    t = num_string.strip().replace(",", ".")
    try:
        return Fraction(t)
    except Exception as e:
        raise ParseError(f"Numero no valido: {num_string}") from e 

def normalize(expr: str) -> str:
    
    #hace las ecuaciones iguales 

    ecuacion_formato = expr.strip()
    ecuacion_formato = ecuacion_formato.replace("−", "-").replace("–", "-").replace("—", "-")
    ecuacion_formato = ecuacion_formato.replace("*", "")
    ecuacion_formato = ecuacion_formato.translate(FORMATO)
    ecuacion_formato = ecuacion_formato.replace(" ", "").lower()
    ecuacion_formato = re.sub(r'(?<![a-z])x1(?![0-9])', 'x', ecuacion_formato)
    ecuacion_formato = re.sub(r'(?<![a-z])x2(?![0-9])', 'y', ecuacion_formato)
    return ecuacion_formato

#devolvera una tupola por que los valores no deben camair 
def split_sides(ecuacion: str) -> tuple[str, str]:
    """Convierte un lado de la ecuación a coeficientes acumulados. Devuelve (coef_x, coef_y, const) para la cadena del lado.
    """
    #seaprar ambos aldos de la ecuacion 
    

    if "=" not in ecuacion:
        raise ParseError("La ecuacion debe tener un +, por ejemplo: 2x+3y=6")
    left, right = ecuacion.split('=', 1)
    if not left or not right:
        raise ParseError("Falta el lado izquierdo o derecho de la ecuacion")
    
    return left, right

#devuelve los coeficientes

def accumulate_terms(side : str) -> tuple[Fraction, Fraction]:

    lado = side.replace("-", "+-")
    partes = [p for p in lado.split("+") if p]

    cx = Fraction(0)
    cy = Fraction(0)
    c0 = Fraction(0)

    for term in partes:
        if "x" in term and "y" in term:
            raise ParseError(f"Término ambiguo (x e y a la vez): '{term}'")

        if "x" in term: 
            coeficiente = term.replace("x", "")
            if coeficiente in ("", "+"):
                valor = Fraction(1)
            elif coeficiente == "-":
                valor = Fraction(-1)
            else:
                valor = Fraction(coeficiente)
            
            cx= cx + valor
        elif "y" in term: 
            coeficiente = term.replace("y", "")
            if coeficiente in ("", "+"):
                valor = Fraction(1)
            elif coeficiente == "-":
                valor = Fraction(-1)
            else:
                valor = Fraction(coeficiente)
            
            cy= cy + valor

        else:
            if re.search(r"[a-z]", term):
                raise ParseError(f"Variable no soportada en 2x2: '{term}'")
            c0 = c0 + to_fraction(term)
    return cx, cy, c0

def prevalidar(expr: str) -> None:
    """Chequeos rápidos antes de parsear en serio."""
    s = expr.strip()
    if s.count("=") != 1:
        raise ParseError("La ecuación debe tener exactamente un '=' (ej: 2x+3y=6).")
    left, right = s.split("=", 1)
    if not left.strip() or not right.strip():
        raise ParseError("Falta el lado izquierdo o el derecho de la ecuación.")
    # Solo variables x,y (acepta x1,x2 y subíndices; se normaliza más adelante)
    letras = re.findall(r"[A-Za-z]", s.translate(FORMATO).lower())
    ilegales = sorted({ch for ch in letras if ch not in {"x", "y"}})
    if ilegales:
        raise ParseError(
            f"Variables no permitidas: {', '.join(ilegales)}. Usa solo x,y o x1,x2."
        )

def convertir_ecuacion(ecuacion: str) -> tuple[Fraction, Fraction, Fraction]:
    """Parsea 'Ax + By = C' y devuelve (A, B, C) como Fraction."""
    prevalidar(ecuacion)
    ecuacionNormalizada = normalize(ecuacion)

    left, right = split_sides(ecuacionNormalizada)
    lx, ly, l0 = accumulate_terms(left)
    rx, ry, r0 = accumulate_terms(right)

    A = lx - rx
    B = ly - ry
    C = r0 - l0

    if A == 0 and B == 0:
        raise ParseError("Ecuación invalida: no contiene x ni y.")

    return A, B, C







