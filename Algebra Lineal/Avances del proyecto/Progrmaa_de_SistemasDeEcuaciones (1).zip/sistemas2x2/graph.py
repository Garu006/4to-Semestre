from __future__ import annotations
from dataclasses import dataclass
from fractions import Fraction
from typing import Optional, Tuple

from models import EcuacionLineal,  Sistema2x2


@dataclass(frozen=True)

class GraphLineInfo:
    pendiente: Optional[Fraction]          # None si vertical
    x_intercepto: Optional[Fraction]    # None si no existe
    y_intercepto: Optional[Fraction]


class GraphReport:
    e1: GraphLineInfo
    e2: GraphLineInfo
    clasificacion: str
    interseccion: Optional[Tuple[Fraction, Fraction]]

def build_graph_report(system: Sistema2x2) -> GraphReport:
    """Construye un reporte con datos listos para trazar ambas rectas."""
    def info(eq: EcuacionLineal) -> GraphLineInfo:
        return GraphLineInfo(
            pendiente=eq.pendiente(),
            x_intercepto=eq.x_intercepto(),
            y_intercepto=eq.y_intercepto(),
        )
    return GraphReport(
        e1=info(system.e1),
        e2=info(system.e2),
        clasificacion=system.clasificacion(),
        interseccion=system.interseccion(),
    )


