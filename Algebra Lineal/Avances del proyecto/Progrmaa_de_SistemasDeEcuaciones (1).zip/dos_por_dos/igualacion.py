# -*- coding: utf-8 -*-
"""
Método de Igualación 2×2 (con fracciones exactas)

Este módulo resuelve un sistema lineal 2×2 por el método de igualación,
mostrando el procedimiento paso a paso y verificando la solución.

Formato del sistema:
    (1) a1·x + b1·y = c1
    (2) a2·x + b2·y = c2
"""

from fractions import Fraction


# ───────────────────────── Utilidades ─────────────────────────

def mostrar_fraccion(r: Fraction) -> str:
    """
    Convierte una fracción en texto "a/b" o entero si el denominador es 1.
    Ejemplos:  3/1 -> "3",  7/2 -> "7/2".
    """
    return f"{r.numerator}/{r.denominator}" if r.denominator != 1 else f"{r.numerator}"


def convertir_a_fraccion(x) -> Fraction:
    """
    Convierte un valor a fractions.Fraction aceptando:
    - Fraction ya existente
    - int, float (se limita el denominador)
    - str con entero, decimal con coma o punto, o fracción "a/b"
    - cadenas vacías/“+”/“-” se interpretan como 0
    """
    if isinstance(x, Fraction):
        return x
    if isinstance(x, (int, float)):
        return Fraction(x).limit_denominator()

    t = str(x).strip().replace(",", ".")
    if "/" in t:
        n, d = t.split("/")
        return Fraction(int(n.strip()), int(d.strip()))

    if t in ("", "+", "-"):
        return Fraction(0, 1)

    return Fraction(t)


# ─────────────────── Resolución por igualación ───────────────────

def igualacion_2x2(a1, b1, c1, a2, b2, c2):
    """
    Resuelve por igualación el sistema:
        a1·x + b1·y = c1
        a2·x + b2·y = c2

    Muestra el procedimiento simbólico (como en cuaderno) y devuelve (x, y).
    """
    # Normalizamos todo a fracciones para trabajar en exacto
    A1, B1, C1 = Fraction(a1), Fraction(b1), Fraction(c1)
    A2, B2, C2 = Fraction(a2), Fraction(b2), Fraction(c2)

    print("Método de Igualación 2×2\n")

    # 1) Mostramos el sistema
    print("Sistema:")
    print(f"{mostrar_fraccion(A1)}x + {mostrar_fraccion(B1)}y = {mostrar_fraccion(C1)}   (1)")
    print(f"{mostrar_fraccion(A2)}x + {mostrar_fraccion(B2)}y = {mostrar_fraccion(C2)}   (2)\n")

    # 2) Despejamos x en cada ecuación
    print("Despejo x en (1):")
    print(f"{mostrar_fraccion(A1)}x + {mostrar_fraccion(B1)}y = {mostrar_fraccion(C1)}"
          f"  ->  {mostrar_fraccion(A1)}x = {mostrar_fraccion(C1)} - {mostrar_fraccion(B1)}y")
    print(f"x = ({mostrar_fraccion(C1)} - {mostrar_fraccion(B1)}y)/{mostrar_fraccion(A1)}\n")

    print("Despejo x en (2):")
    print(f"{mostrar_fraccion(A2)}x + {mostrar_fraccion(B2)}y = {mostrar_fraccion(C2)}"
          f"  ->  {mostrar_fraccion(A2)}x = {mostrar_fraccion(C2)} - {mostrar_fraccion(B2)}y")
    print(f"x = ({mostrar_fraccion(C2)} - {mostrar_fraccion(B2)}y)/{mostrar_fraccion(A2)}\n")

    # 3) Igualamos las dos expresiones de x y hacemos producto cruzado
    print("Igualo x de (1) y (2):")
    print(f"({mostrar_fraccion(C1)} - {mostrar_fraccion(B1)}y)/{mostrar_fraccion(A1)}"
          f" = ({mostrar_fraccion(C2)} - {mostrar_fraccion(B2)}y)/{mostrar_fraccion(A2)}")
    print(f"-> {mostrar_fraccion(A2)}({mostrar_fraccion(C1)} - {mostrar_fraccion(B1)}y)"
          f" = {mostrar_fraccion(A1)}({mostrar_fraccion(C2)} - {mostrar_fraccion(B2)}y)")

    # 4) Expandimos y agrupamos términos en y
    #    coeficiente_de_y · y = termino_independiente
    coeficiente_de_y = (-A2 * B1) + (A1 * B2)
    termino_independiente = (A1 * C2) - (A2 * C1)

    print("Expandimos y reagrupamos:")
    print(f"({mostrar_fraccion(-A2*B1)} + {mostrar_fraccion(A1*B2)})y"
          f" = {mostrar_fraccion(A1*C2)} - {mostrar_fraccion(A2*C1)}")
    print(f"{mostrar_fraccion(coeficiente_de_y)}y = {mostrar_fraccion(termino_independiente)}")

    # 5) Casos especiales: sin solución o infinitas soluciones
    if coeficiente_de_y == 0:
        if termino_independiente == 0:
            print("\nConclusión: ecuaciones dependientes → infinitas soluciones")
        else:
            print("\nConclusión: sistema inconsistente → sin solución")
        return

    # 6) Resolución para y
    y = termino_independiente / coeficiente_de_y
    print(f"y = {mostrar_fraccion(termino_independiente)}/{mostrar_fraccion(coeficiente_de_y)}"
          f" = {mostrar_fraccion(y)}\n")

    # 7) Sustituimos y en (1) para hallar x
    print("Reemplazo y en (1):")
    print(f"{mostrar_fraccion(A1)}x + {mostrar_fraccion(B1)}({mostrar_fraccion(y)}) = {mostrar_fraccion(C1)}")
    numerador_x = C1 - B1 * y
    print(f"{mostrar_fraccion(A1)}x = {mostrar_fraccion(C1)} - {mostrar_fraccion(B1*y)}")
    x = numerador_x / A1
    print(f"x = {mostrar_fraccion(numerador_x)}/{mostrar_fraccion(A1)} = {mostrar_fraccion(x)}\n")

    # 8) Comprobación en ambas ecuaciones
    lado_izq_1 = A1*x + B1*y
    lado_izq_2 = A2*x + B2*y
    print("Comprobación:")
    print(f"(1) {mostrar_fraccion(A1)}·{mostrar_fraccion(x)} + {mostrar_fraccion(B1)}·{mostrar_fraccion(y)}"
          f" = {mostrar_fraccion(lado_izq_1)}   {'Correcto' if lado_izq_1 == C1 else 'Incorrecto'}")
    print(f"(2) {mostrar_fraccion(A2)}·{mostrar_fraccion(x)} + {mostrar_fraccion(B2)}·{mostrar_fraccion(y)}"
          f" = {mostrar_fraccion(lado_izq_2)}   {'Correcto' if lado_izq_2 == C2 else 'Incorrecto'}\n")

    # 9) Resultado final
    print("Solución final:")
    print(f"(x, y) = ({mostrar_fraccion(x)}, {mostrar_fraccion(y)})")
    return x, y


# ───────────────────── Entrada interactiva ─────────────────────

def pedir_coeficientes_2x2() -> tuple[Fraction, Fraction, Fraction, Fraction, Fraction, Fraction]:
    """
    Pide por teclado los coeficientes del sistema 2×2.
    Acepta enteros, decimales (con coma o punto) y fracciones a/b.
    """
    print("\nIngresa los coeficientes del sistema 2×2 (enteros, decimales o fracciones a/b).")

    # (1) a1·x + b1·y = c1
    a1 = convertir_a_fraccion(input("a1: "))
    b1 = convertir_a_fraccion(input("b1: "))
    c1 = convertir_a_fraccion(input("c1: "))

    # (2) a2·x + b2·y = c2
    a2 = convertir_a_fraccion(input("a2: "))
    b2 = convertir_a_fraccion(input("b2: "))
    c2 = convertir_a_fraccion(input("c2: "))

    return a1, b1, c1, a2, b2, c2


def menu():
    """
    Menú interactivo del método de igualación 2×2.
    """
    while True:
        print("=" * 45)
        print("Calculadora — Método de Igualación 2×2")
        print("=" * 45)
        print("1. Resolver un sistema 2×2 (ingresar coeficientes)")
        print("2. Limpiar pantalla")
        print("3. Salir")
        opcion = input("\nElige una opción: ").strip()

        if opcion == "1":
            try:
                a1, b1, c1, a2, b2, c2 = pedir_coeficientes_2x2()
                igualacion_2x2(a1, b1, c1, a2, b2, c2)
            except Exception as e:
                print(f"\nIngreso inválido: {e}\n")
            input("Presiona Enter para continuar")
        elif opcion == "2":
            print("\n" * 80)   # “Borrón” rápido de pantalla
        elif opcion == "3":
            print("¡Nos vemos!")
            break
        else:
            print("Opción inválida")


# Punto de entrada si se ejecuta directamente este archivo
if __name__ == "__main__":
    menu()
