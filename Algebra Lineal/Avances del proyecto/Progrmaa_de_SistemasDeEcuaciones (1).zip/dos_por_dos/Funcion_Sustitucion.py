# dos_por_dos/Funcion_Sustitucion.py
# -*- coding: utf-8 -*-
from fractions import Fraction

# ─────────────── Utilidades ───────────────
def formatear(fr: Fraction) -> str:
    """Devuelve fracción como 'p/q' o entero si aplica."""
    return f"{fr.numerator}" if fr.denominator == 1 else f"{fr.numerator}/{fr.denominator}"

def leer_fraction(prompt: str) -> Fraction:
    """Lee un número (int, decimal o a/b) y lo convierte a Fraction."""
    while True:
        txt = input(prompt).strip().replace(",", ".")
        try:
            return Fraction(txt)
        except Exception:
            print("Entrada inválida. Ejemplos: 3, -2, 4/5, 1.25")

# ─────────────── Clase principal ───────────────
class Sistema2x2:
    """Representa un sistema lineal 2x2: a11*x + a12*y = b1 ; a21*x + a22*y = b2"""

    def __init__(self, a11, a12, b1, a21, a22, b2):
        self.a11, self.a12, self.b1 = Fraction(a11), Fraction(a12), Fraction(b1)
        self.a21, self.a22, self.b2 = Fraction(a21), Fraction(a22), Fraction(b2)

    def determinante(self) -> Fraction:
        return self.a11 * self.a22 - self.a12 * self.a21

    def tiene_solucion(self) -> bool:
        return self.determinante() != 0

    def resolver_por_sustitucion(self):
        """Resuelve por sustitución paso a paso."""
        if not self.tiene_solucion():
            raise ValueError("Determinante cero → sin solución única.")

        # Caso especial si a11=0
        if self.a11 == 0:
            if self.a12 == 0:
                raise ValueError("No se puede despejar ninguna variable.")
            y = self.b1 / self.a12
            if self.a21 == 0:
                raise ValueError("No se puede despejar x en la segunda ecuación.")
            x = (self.b2 - self.a22 * y) / self.a21
            return x, y

        # Caso general
        coef_y = -self.a21 * self.a12 + self.a22 * self.a11
        if coef_y == 0:
            raise ValueError("Coeficiente de y es cero, no se puede resolver.")
        y = (self.b2 * self.a11 - self.a21 * self.b1) / coef_y
        x = (self.b1 - self.a12 * y) / self.a11
        return x, y

    def resolver_por_cramer(self):
        """Resuelve usando la regla de Cramer."""
        det = self.determinante()
        if det == 0:
            raise ValueError("Determinante cero → sin solución única.")
        det_x = self.b1 * self.a22 - self.a12 * self.b2
        det_y = self.a11 * self.b2 - self.b1 * self.a21
        return det_x / det, det_y / det

# ─────────────── Menú interactivo ───────────────
def leer_coeficientes() -> Sistema2x2:
    """Pide al usuario los coeficientes del sistema y crea el objeto."""
    print("\nSistema: a11·x + a12·y = b1 ; a21·x + a22·y = b2")
    a11 = leer_fraction("a11: "); a12 = leer_fraction("a12: "); b1 = leer_fraction("b1: ")
    a21 = leer_fraction("a21: "); a22 = leer_fraction("a22: "); b2 = leer_fraction("b2: ")
    return Sistema2x2(a11, a12, b1, a21, a22, b2)

def menu():
    sistema = None
    while True:
        print("\n=== Calculadora 2x2 ===")
        print("1) Ingresar sistema")
        print("2) Resolver por Sustitución")
        print("3) Resolver por Cramer")
        print("0) Salir")
        op = input("Opción: ").strip()

        if op == "1":
            sistema = leer_coeficientes()
        elif op == "2":
            if sistema:
                try:
                    x, y = sistema.resolver_por_sustitucion()
                    print(f"Resultado: x = {formatear(x)}, y = {formatear(y)}")
                except ValueError as e:
                    print(e)
            else:
                print("Primero ingresa el sistema.")
        elif op == "3":
            if sistema:
                try:
                    x, y = sistema.resolver_por_cramer()
                    print(f"Resultado: x = {formatear(x)}, y = {formatear(y)}")
                except ValueError as e:
                    print(e)
            else:
                print("Primero ingresa el sistema.")
        elif op == "0":
            print("Saliendo...")
            break
        else:
            print("Opción inválida.")

# ─────────────── Entrada principal ───────────────
def main():
    menu()

if __name__ == "__main__":
    main()
